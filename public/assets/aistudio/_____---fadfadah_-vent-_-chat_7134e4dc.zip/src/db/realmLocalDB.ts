/**
 * Local Realm DB Engine for Android APK (com.fadfadahnative v3.8.2+)
 * Acts as the fast 0ms offline-first persistence layer on the Android device,
 * automatically synchronized with the standalone Fadfadah Server & WebSocket Hub.
 * Zero mock/fake data — stores only real authenticated account & synced conversations.
 */

export type ChatRoomType = 'LINK_BASED' | 'RANDOM';
export type ChatRoomStatus = 'PENDING' | 'ACCEPTED' | 'BLOCKED';
export type MessageStatus = 'SENT' | 'READ';
export type MediaType = 'text' | 'image' | 'sticker';
export type PremiumPlan = 'free' | 'weekly' | 'monthly' | 'quarterly';

export interface RealmObjectSchema {
  name: string;
  primaryKey: string;
  properties: Record<string, string>;
}

export interface RealmUser {
  id: string;
  nickname: string;
  avatar_url: string;
  frame_id: number;
  interests: string[];
  languages: string[];
  country: string;
  embedding_vector: number[];
  is_premium: boolean;
  premium_plan: PremiumPlan;
  points: number;
  unlocked_frames: number[];
  blocked_user_ids: string[];
  daily_random_count: number;
  last_random_date: string;
  is_self: boolean;
  is_online: boolean;
  bio: string;
}

export interface RealmPersonalLink {
  id: string;
  user_id: string;
  slug: string;
  is_active: boolean;
  visits_count: number;
  created_at: number;
}

export interface RealmChatRoom {
  id: string;
  type: ChatRoomType;
  participant_a: string;
  participant_b: string;
  status: ChatRoomStatus;
  unread_count: number;
  last_message_preview: string;
  last_message_at: number;
  created_at: number;
}

export interface RealmMessage {
  id: string;
  room_id: string;
  sender_id: string;
  content: string;
  media_url: string;
  media_type: MediaType;
  ai_flag_score: number;
  ai_flag_reason: string;
  is_frozen: boolean;
  status: MessageStatus;
  created_at: number;
}

export interface RealmReportModeration {
  id: string;
  reporter_id: string;
  reported_user_id: string;
  room_id: string;
  reason: string;
  recent_messages_log: string;
  ai_summary: string;
  created_at: number;
}

export interface RealmPublicVent {
  id: string;
  author_id: string;
  topic: string;
  content: string;
  likes_count: number;
  liked_by_me: boolean;
  ai_flag_score: number;
  created_at: number;
}

export interface RealmAppSettings {
  id: string;
  theme: 'dark' | 'light';
  language: 'ar' | 'en';
  auth_token: string;
  custom_server_url: string;
}

export type RealmCollectionName =
  | 'users'
  | 'personal_links'
  | 'chat_rooms'
  | 'messages'
  | 'reports_moderation'
  | 'public_vents'
  | 'app_settings';

export interface RealmStoreMap {
  users: RealmUser;
  personal_links: RealmPersonalLink;
  chat_rooms: RealmChatRoom;
  messages: RealmMessage;
  reports_moderation: RealmReportModeration;
  public_vents: RealmPublicVent;
  app_settings: RealmAppSettings;
}

export const FADFADAH_REALM_SCHEMAS: RealmObjectSchema[] = [
  {
    name: 'users',
    primaryKey: 'id',
    properties: {
      id: 'uuid',
      nickname: 'string',
      avatar_url: 'string',
      frame_id: 'int',
      interests: 'string[]',
      languages: 'string[]',
      country: 'string',
      embedding_vector: 'float[]',
      is_premium: 'bool',
      premium_plan: 'string',
      points: 'int',
      unlocked_frames: 'int[]',
      blocked_user_ids: 'string[]',
      daily_random_count: 'int',
      last_random_date: 'string',
      is_self: 'bool',
      is_online: 'bool',
      bio: 'string',
    },
  },
  {
    name: 'personal_links',
    primaryKey: 'id',
    properties: {
      id: 'uuid',
      user_id: 'uuid',
      slug: 'string',
      is_active: 'bool',
      visits_count: 'int',
      created_at: 'date',
    },
  },
  {
    name: 'chat_rooms',
    primaryKey: 'id',
    properties: {
      id: 'uuid',
      type: 'string',
      participant_a: 'uuid',
      participant_b: 'uuid',
      status: 'string',
      unread_count: 'int',
      last_message_preview: 'string',
      last_message_at: 'date',
      created_at: 'date',
    },
  },
  {
    name: 'messages',
    primaryKey: 'id',
    properties: {
      id: 'uuid',
      room_id: 'uuid',
      sender_id: 'uuid',
      content: 'string',
      media_url: 'string',
      media_type: 'string',
      ai_flag_score: 'float',
      ai_flag_reason: 'string',
      is_frozen: 'bool',
      status: 'string',
      created_at: 'date',
    },
  },
  {
    name: 'reports_moderation',
    primaryKey: 'id',
    properties: {
      id: 'uuid',
      reporter_id: 'uuid',
      reported_user_id: 'uuid',
      room_id: 'uuid',
      reason: 'string',
      recent_messages_log: 'string',
      ai_summary: 'string',
      created_at: 'date',
    },
  },
  {
    name: 'public_vents',
    primaryKey: 'id',
    properties: {
      id: 'uuid',
      author_id: 'uuid',
      topic: 'string',
      content: 'string',
      likes_count: 'int',
      liked_by_me: 'bool',
      ai_flag_score: 'float',
      created_at: 'date',
    },
  },
  {
    name: 'app_settings',
    primaryKey: 'id',
    properties: {
      id: 'string',
      theme: 'string',
      language: 'string',
      auth_token: 'string',
      custom_server_url: 'string',
    },
  },
];

export function generateUUID(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

const DB_NAME = 'FadfadahAndroidRealmDB_v382_Prod';
const DB_VERSION = 1;

export interface RealmTransactionScope {
  create<K extends RealmCollectionName>(
    collection: K,
    data: RealmStoreMap[K],
    mode?: 'modified' | 'never'
  ): RealmStoreMap[K];
  delete<K extends RealmCollectionName>(collection: K, id: string): void;
}

export class LocalRealmDB {
  private idb: IDBDatabase | null = null;
  private memory: { [K in RealmCollectionName]: Map<string, RealmStoreMap[K]> } = {
    users: new Map(),
    personal_links: new Map(),
    chat_rooms: new Map(),
    messages: new Map(),
    reports_moderation: new Map(),
    public_vents: new Map(),
    app_settings: new Map(),
  };
  private listeners: Set<() => void> = new Set();
  private initialized = false;
  public readonly schemaVersion = 382;

  async open(): Promise<this> {
    if (this.initialized) return this;

    this.idb = await new Promise<IDBDatabase>((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        for (const schema of FADFADAH_REALM_SCHEMAS) {
          if (!db.objectStoreNames.contains(schema.name)) {
            db.createObjectStore(schema.name, { keyPath: schema.primaryKey });
          }
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });

    for (const schema of FADFADAH_REALM_SCHEMAS) {
      const col = schema.name as RealmCollectionName;
      const rows = await this.readAllFromIDB(col);
      const map = this.memory[col] as Map<string, unknown>;
      map.clear();
      for (const row of rows) {
        const record = row as unknown as Record<string, unknown>;
        map.set(String(record[schema.primaryKey]), row);
      }
    }

    if (!this.memory.app_settings.has('global')) {
      await this.write((tx) => {
        tx.create('app_settings', {
          id: 'global',
          theme: 'dark',
          language: 'ar',
          auth_token: '',
          custom_server_url: '',
        });
      });
    }

    this.initialized = true;
    this.notify();
    return this;
  }

  private readAllFromIDB<K extends RealmCollectionName>(storeName: K): Promise<RealmStoreMap[K][]> {
    return new Promise((resolve, reject) => {
      if (!this.idb) return resolve([]);
      const tx = this.idb.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result as RealmStoreMap[K][]);
      req.onerror = () => reject(req.error);
    });
  }

  objects<K extends RealmCollectionName>(collection: K): RealmStoreMap[K][] {
    return Array.from(this.memory[collection].values());
  }

  objectForPrimaryKey<K extends RealmCollectionName>(
    collection: K,
    id: string
  ): RealmStoreMap[K] | undefined {
    return this.memory[collection].get(id);
  }

  findSelfUser(): RealmUser | undefined {
    return this.objects('users').find((u) => u.is_self);
  }

  findPersonalLink(): RealmPersonalLink | undefined {
    const self = this.findSelfUser();
    if (!self) return undefined;
    return this.objects('personal_links').find((l) => l.user_id === self.id);
  }

  getSettings(): RealmAppSettings {
    const s = this.memory.app_settings.get('global');
    return (
      s ?? {
        id: 'global',
        theme: 'dark',
        language: 'ar',
        auth_token: '',
        custom_server_url: '',
      }
    );
  }

  async write(mutator: (tx: RealmTransactionScope) => void): Promise<void> {
    const dirtyStores = new Set<RealmCollectionName>();
    const deletions: Array<{ collection: RealmCollectionName; id: string }> = [];

    const scope: RealmTransactionScope = {
      create: <K extends RealmCollectionName>(
        collection: K,
        data: RealmStoreMap[K],
        mode: 'modified' | 'never' = 'modified'
      ): RealmStoreMap[K] => {
        const map = this.memory[collection] as Map<string, RealmStoreMap[K]>;
        const pk = (data as unknown as Record<string, string>).id;
        if (mode === 'never' && map.has(pk)) {
          throw new Error(`Duplicate primary key ${pk} in ${collection}`);
        }
        const cloned = structuredClone(data);
        map.set(pk, cloned);
        dirtyStores.add(collection);
        return cloned;
      },
      delete: <K extends RealmCollectionName>(collection: K, id: string) => {
        const map = this.memory[collection] as Map<string, RealmStoreMap[K]>;
        if (map.delete(id)) {
          dirtyStores.add(collection);
          deletions.push({ collection, id });
        }
      },
    };

    mutator(scope);

    if (this.idb && dirtyStores.size > 0) {
      const storeList = Array.from(dirtyStores);
      await new Promise<void>((resolve, reject) => {
        const tx = this.idb!.transaction(storeList, 'readwrite');
        for (const del of deletions) {
          tx.objectStore(del.collection).delete(del.id);
        }
        for (const col of storeList) {
          const store = tx.objectStore(col);
          for (const item of this.memory[col].values()) {
            store.put(item);
          }
        }
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    }

    this.notify();
  }

  async clearAllUserDataPreservePreferences(): Promise<void> {
    const currentSettings = this.getSettings();
    for (const schema of FADFADAH_REALM_SCHEMAS) {
      const col = schema.name as RealmCollectionName;
      (this.memory[col] as Map<string, unknown>).clear();
    }

    if (this.idb) {
      const allNames = FADFADAH_REALM_SCHEMAS.map((s) => s.name);
      await new Promise<void>((resolve, reject) => {
        const tx = this.idb!.transaction(allNames, 'readwrite');
        for (const name of allNames) {
          tx.objectStore(name).clear();
        }
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    }

    await this.write((tx) => {
      tx.create('app_settings', {
        ...currentSettings,
        auth_token: '',
      });
    });
  }

  exportSnapshotJSON(): string {
    const payload: Record<string, unknown[]> = {};
    for (const schema of FADFADAH_REALM_SCHEMAS) {
      const col = schema.name as RealmCollectionName;
      if (col === 'app_settings') {
        // Mask raw auth_token in exported JSON
        payload[col] = this.objects('app_settings').map((s) => ({ ...s, auth_token: '***' }));
      } else {
        payload[col] = this.objects(col);
      }
    }
    return JSON.stringify(
      {
        engine: 'FadfadahAndroidRealmDB',
        package: 'com.fadfadahnative',
        schemaVersion: this.schemaVersion,
        exportedAt: new Date().toISOString(),
        collections: payload,
      },
      null,
      2
    );
  }

  addListener(cb: () => void): () => void {
    this.listeners.add(cb);
    return () => {
      this.listeners.delete(cb);
    };
  }

  private notify(): void {
    for (const cb of this.listeners) {
      cb();
    }
  }
}

export const realmDB = new LocalRealmDB();
