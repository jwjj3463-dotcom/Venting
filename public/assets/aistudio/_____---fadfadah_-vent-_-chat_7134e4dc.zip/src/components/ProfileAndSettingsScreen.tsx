import React, { useEffect, useRef, useState } from 'react';
import {
  Crown,
  Coins,
  Database,
  Smartphone,
  Trash2,
  Download,
  Check,
  ChevronLeft,
  ChevronRight,
  Lock,
  Sparkles,
  ImagePlus,
  Server,
} from 'lucide-react';
import {
  AVATAR_PRESETS,
  FramedAvatar,
  PROFILE_FRAMES,
} from './FramedAvatar';
import {
  FADFADAH_REALM_SCHEMAS,
  PremiumPlan,
  realmDB,
  RealmAppSettings,
  RealmPersonalLink,
  RealmUser,
} from '../db/realmLocalDB';
import { fadfadahClient } from '../services/fadfadahNetworkClient';
import { nativeCopyText } from '../services/androidNative';
import {
  AppLang,
  AVAILABLE_COUNTRIES,
  AVAILABLE_INTERESTS,
  AVAILABLE_LANGUAGES,
  TRANSLATIONS,
} from '../i18n/translations';

interface ProfileAndSettingsScreenProps {
  selfUser: RealmUser;
  personalLink: RealmPersonalLink;
  settings: RealmAppSettings;
  onToggleTheme: () => void;
  onToggleLanguage: () => void;
  initialSubSection?: 'main' | 'monetization' | 'realm_android';
}

export const ProfileAndSettingsScreen: React.FC<ProfileAndSettingsScreenProps> = ({
  selfUser,
  personalLink,
  settings,
  onToggleTheme,
  onToggleLanguage,
  initialSubSection = 'main',
}) => {
  const lang: AppLang = settings.language;
  const t = TRANSLATIONS[lang];

  const [subView, setSubView] = useState<'main' | 'monetization' | 'realm_android'>(
    initialSubSection
  );
  const [nickname, setNickname] = useState(selfUser.nickname);
  const [slug, setSlug] = useState(personalLink.slug);
  const [country, setCountry] = useState(selfUser.country);
  const [bio, setBio] = useState(selfUser.bio);
  const [avatarUrl, setAvatarUrl] = useState(selfUser.avatar_url);
  const [frameId, setFrameId] = useState(selfUser.frame_id);
  const [interests, setInterests] = useState<string[]>(selfUser.interests);
  const [languages, setLanguages] = useState<string[]>(selfUser.languages);

  const [serverUrlInput, setServerUrlInput] = useState(settings.custom_server_url || '');
  const [connState, setConnState] = useState(() => fadfadahClient.getConnectionState());
  const [savingServerUrl, setSavingServerUrl] = useState(false);

  const [saveToast, setSaveToast] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);

  const avatarUploadRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    const unsub = fadfadahClient.subscribe(() => {
      setConnState(fadfadahClient.getConnectionState());
    });
    return unsub;
  }, []);

  const toggleInterest = (item: string) => {
    setInterests((prev) =>
      prev.includes(item)
        ? prev.length > 1
          ? prev.filter((x) => x !== item)
          : prev
        : [...prev, item]
    );
  };

  const toggleLanguageItem = (item: string) => {
    setLanguages((prev) =>
      prev.includes(item)
        ? prev.length > 1
          ? prev.filter((x) => x !== item)
          : prev
        : [...prev, item]
    );
  };

  const handleCustomAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      setSaveToast(lang === 'ar' ? 'الصورة أكبر من 2 ميجابايت.' : 'Avatar exceeds 2MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setAvatarUrl(String(reader.result));
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleSelectFrame = async (targetFrameId: number) => {
    const def = PROFILE_FRAMES.find((f) => f.id === targetFrameId);
    if (!def) return;

    const isUnlocked = selfUser.is_premium || selfUser.unlocked_frames.includes(targetFrameId);
    if (isUnlocked) {
      setFrameId(targetFrameId);
      return;
    }

    if (def.premiumOnly && !selfUser.is_premium) {
      setSubView('monetization');
      return;
    }

    if (selfUser.points >= def.costPoints) {
      const ok = await fadfadahClient.modifyPoints({
        deltaPoints: -def.costPoints,
        unlockFrameId: targetFrameId,
      });
      if (ok) {
        setFrameId(targetFrameId);
        setSaveToast(
          lang === 'ar'
            ? `تم فتح ${def.nameAr} مقابل ${def.costPoints} نقطة!`
            : `Unlocked ${def.nameEn}!`
        );
      }
    } else {
      setSubView('monetization');
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fadfadahClient.updateProfile({
      nickname: nickname.trim() || selfUser.nickname,
      slug: slug.trim() || personalLink.slug,
      country,
      bio: bio.trim(),
      avatar_url: avatarUrl,
      frame_id: frameId,
      interests,
      languages,
    });

    if (!res.ok) {
      setSaveToast(res.error || (lang === 'ar' ? 'تعذر الحفظ.' : 'Save failed.'));
      return;
    }
    const updatedLink = realmDB.findPersonalLink();
    if (updatedLink) setSlug(updatedLink.slug);
    setSaveToast(t.savedSuccess);
    setTimeout(() => setSaveToast(''), 2600);
  };

  const handleActivatePlan = async (plan: PremiumPlan, bonusPoints: number) => {
    await fadfadahClient.activatePlan(plan, bonusPoints);
    setSaveToast(
      lang === 'ar'
        ? 'تم تحديث اشتراكك ومزامنته مع السيرفر وRealm DB!'
        : 'Subscription synced with Server & Local Realm DB!'
    );
    setTimeout(() => setSaveToast(''), 2500);
  };

  const handleAddPointsPack = async (pts: number) => {
    await fadfadahClient.modifyPoints({ deltaPoints: pts });
    setSaveToast(lang === 'ar' ? `تمت إضافة +${pts} نقطة!` : `Added +${pts} points!`);
    setTimeout(() => setSaveToast(''), 2200);
  };

  const handleSaveServerEndpoint = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingServerUrl(true);
    const connected = await fadfadahClient.updateCustomServerUrl(serverUrlInput);
    setSavingServerUrl(false);
    setSaveToast(
      connected
        ? lang === 'ar'
          ? 'تم الاتصال بالسيرفر بنجاح ومزامنة الحساب!'
          : 'Connected to server & synced!'
        : lang === 'ar'
        ? 'تعذر الوصول للسيرفر المحدد، يعمل التطبيق حالياً بوضع Realm المحلي.'
        : 'Server unreachable; running on Local Realm offline cache.'
    );
  };

  const handleExportRealm = () => {
    const json = realmDB.exportSnapshotJSON();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fadfadah_android_realm_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePermanentDelete = async () => {
    await fadfadahClient.deleteAccountPermanently();
    setShowDeleteConfirm(false);
    const freshSelf = realmDB.findSelfUser();
    const freshLink = realmDB.findPersonalLink();
    if (freshSelf) {
      setNickname(freshSelf.nickname);
      setAvatarUrl(freshSelf.avatar_url);
      setFrameId(freshSelf.frame_id);
    }
    if (freshLink) setSlug(freshLink.slug);
    setSaveToast(
      lang === 'ar'
        ? 'تم حذف الحساب نهائياً من السيرفر ومن هاتفك وإنشاء هوية جديدة.'
        : 'Account deleted permanently from server and device.'
    );
  };

  const DisclosureChevron = lang === 'ar' ? ChevronLeft : ChevronRight;

  if (subView === 'monetization') {
    return (
      <div className="p-4 sm:p-5 space-y-5 max-w-3xl mx-auto">
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={() => setSubView('main')}
            className="min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#1E1B2E] border border-slate-200 dark:border-white/10 text-xs font-semibold text-slate-700 dark:text-slate-200"
          >
            {lang === 'ar' ? 'رجوع للملف الشخصي' : 'Back'}
          </button>
          <div className="text-xs font-mono-num font-bold text-[#8B5CF6]">
            {lang === 'ar' ? `رصيد النقاط: ${selfUser.points}` : `Points: ${selfUser.points}`}
          </div>
        </div>

        <div className="rounded-3xl bg-[#2D1B69] text-white p-6 space-y-4">
          <div className="flex items-center gap-2.5">
            <Crown className="w-6 h-6 text-amber-300 shrink-0" />
            <h2 className="text-lg font-bold">
              {lang === 'ar' ? 'باقات فضفضة المميزة (Android Billing)' : 'Fadfadah Premium Plans'}
            </h2>
          </div>
          <p className="text-xs text-purple-100/85 leading-relaxed">
            {lang === 'ar'
              ? 'محادثات عشوائية غير محدودة · إزالة كافة الإعلانات · فتح جميع الإطارات الحصرية · أولوية الظهور في قائمة المتصلين الآن.'
              : 'Unlimited random matches · Ad-free · All VIP frames · Priority online visibility.'}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            {[
              { id: 'weekly' as PremiumPlan, titleAr: 'أسبوعية', titleEn: 'Weekly', price: '$2.99', bonus: 150 },
              { id: 'monthly' as PremiumPlan, titleAr: 'شهرية', titleEn: 'Monthly', price: '$7.99', bonus: 500 },
              { id: 'quarterly' as PremiumPlan, titleAr: '3 أشهر', titleEn: '3 Months', price: '$18.99', bonus: 1500 },
            ].map((pkg) => {
              const active = selfUser.premium_plan === pkg.id && selfUser.is_premium;
              return (
                <button
                  key={pkg.id}
                  type="button"
                  onClick={() => handleActivatePlan(pkg.id, pkg.bonus)}
                  className={`p-4 rounded-2xl text-start border transition-colors flex flex-col justify-between gap-3 ${
                    active
                      ? 'bg-[#8B5CF6] border-white text-white'
                      : 'bg-white/10 active:bg-white/20 border-white/15 text-white'
                  }`}
                >
                  <div>
                    <p className="text-sm font-bold">{lang === 'ar' ? pkg.titleAr : pkg.titleEn}</p>
                    <p className="text-xl font-bold font-mono-num mt-1">{pkg.price}</p>
                    <p className="text-[11px] text-purple-200 mt-1">
                      +{pkg.bonus} {lang === 'ar' ? 'نقطة' : 'pts'}
                    </p>
                  </div>
                  <span className="text-xs font-semibold underline">
                    {active ? (lang === 'ar' ? 'مفعّلة' : 'Active') : lang === 'ar' ? 'تفعيل' : 'Activate'}
                  </span>
                </button>
              );
            })}
          </div>

          {selfUser.is_premium && (
            <button
              type="button"
              onClick={() => handleActivatePlan('free', 0)}
              className="text-xs text-purple-200 underline pt-1"
            >
              {lang === 'ar' ? 'إرجاع للحساب المجاني' : 'Revert to Free Tier'}
            </button>
          )}
        </div>

        <div className="rounded-3xl bg-white dark:bg-[#1E1B2E] border border-slate-200 dark:border-white/10 p-6 space-y-4">
          <div className="flex items-center gap-2">
            <Coins className="w-5 h-5 text-amber-500" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {lang === 'ar' ? 'شحن النقاط الرصيدية' : 'Point Packs'}
            </h3>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {[
              { pts: 150, label: '$0.99' },
              { pts: 500, label: '$2.49' },
              { pts: 1200, label: '$4.99' },
            ].map((pack) => (
              <button
                key={pack.pts}
                type="button"
                onClick={() => handleAddPointsPack(pack.pts)}
                className="min-h-[64px] p-3 rounded-2xl bg-slate-50 dark:bg-[#151221] active:border-[#8B5CF6] border border-slate-200 dark:border-white/10 text-center space-y-1"
              >
                <p className="text-sm font-bold font-mono-num text-[#8B5CF6]">+{pack.pts}</p>
                <p className="text-xs text-slate-600 dark:text-slate-400 font-mono-num">{pack.label}</p>
              </button>
            ))}
          </div>
        </div>

        {saveToast && (
          <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800/60 text-xs font-semibold text-emerald-800 dark:text-emerald-200">
            {saveToast}
          </div>
        )}
      </div>
    );
  }

  if (subView === 'realm_android') {
    const capBuildCmd = `npm install && npm run android:init && npm run android:open`;
    return (
      <div className="p-4 sm:p-5 space-y-5 max-w-3xl mx-auto">
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={() => setSubView('main')}
            className="min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#1E1B2E] border border-slate-200 dark:border-white/10 text-xs font-semibold text-slate-700 dark:text-slate-200"
          >
            {lang === 'ar' ? 'رجوع للملف الشخصي' : 'Back'}
          </button>
          <span className="text-xs font-mono-num text-slate-500 dark:text-slate-400">
            com.fadfadahnative · APK
          </span>
        </div>

        {/* Live Server Connection Endpoint Configurator for Android APK */}
        <form
          onSubmit={handleSaveServerEndpoint}
          className="rounded-3xl bg-white dark:bg-[#1E1B2E] border border-slate-200 dark:border-white/10 p-5 space-y-4"
        >
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Server className="w-5 h-5 text-[#8B5CF6]" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {lang === 'ar' ? 'ربط تطبيق الأندرويد بالسيرفر المستقل' : 'Android Server Endpoint'}
              </h3>
            </div>
            <span
              className={`text-xs font-bold ${
                connState === 'connected'
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-amber-600 dark:text-amber-400'
              }`}
            >
              {connState === 'connected'
                ? lang === 'ar'
                  ? 'متصل بالسيرفر الحقيقي'
                  : 'Connected Live'
                : lang === 'ar'
                ? 'وضع Realm المحلي'
                : 'Offline Realm Mode'}
            </span>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            {lang === 'ar'
              ? 'العنوان الفعلي النشط حالياً: '
              : 'Active Server Endpoint: '}
            <span className="font-mono-num text-slate-800 dark:text-slate-200" dir="ltr">
              {fadfadahClient.getServerBaseUrl()}
            </span>
          </p>

          <div className="space-y-2">
            <input
              type="url"
              value={serverUrlInput}
              onChange={(e) => setServerUrlInput(e.target.value)}
              placeholder="http://192.168.1.15:3000 أو https://api.yourdomain.com"
              dir="ltr"
              className="w-full h-11 px-3.5 rounded-xl bg-slate-50 dark:bg-[#151221] border border-slate-200 dark:border-white/10 text-xs font-mono-num text-slate-900 dark:text-white"
            />
            <div className="flex items-center gap-2">
              <button
                type="submit"
                disabled={savingServerUrl}
                className="min-h-[42px] px-4 py-2 rounded-xl bg-[#8B5CF6] text-white text-xs font-bold"
              >
                {savingServerUrl
                  ? lang === 'ar'
                    ? 'جارٍ الاتصال...'
                    : 'Connecting...'
                  : lang === 'ar'
                  ? 'حفظ والاتصال بالسيرفر'
                  : 'Save & Connect'}
              </button>
              {serverUrlInput && (
                <button
                  type="button"
                  onClick={() => {
                    setServerUrlInput('');
                    fadfadahClient.updateCustomServerUrl('');
                  }}
                  className="min-h-[42px] px-3 py-2 rounded-xl bg-slate-100 dark:bg-[#151221] text-xs font-semibold text-slate-600 dark:text-slate-300"
                >
                  {lang === 'ar' ? 'الافتراضي' : 'Default'}
                </button>
              )}
            </div>
          </div>
        </form>

        {/* Android Studio APK Packaging Commands */}
        <div className="rounded-3xl bg-[#2D1B69] text-white p-5 space-y-3">
          <div className="flex items-center gap-2.5">
            <Smartphone className="w-5 h-5 text-[#A78BFA]" />
            <h2 className="text-sm font-bold">
              {lang === 'ar'
                ? 'استخراج ملف الـ APK الأصلي على جهاز الكمبيوتر'
                : 'Build Native Android APK on Your PC'}
            </h2>
          </div>

          <p className="text-xs text-purple-100/85 leading-relaxed">
            {lang === 'ar'
              ? 'جميع حزم Capacitor Android مضمنة بالكامل داخل المشروع بدون أي ارتباط خارجي. بعد تنزيل المشروع على كمبيوترك نفذ الأمر التالي لفتح Android Studio وبناء الـ APK:'
              : 'All Capacitor Android packages are bundled locally. Run this on your PC to open Android Studio and build the APK:'}
          </p>

          <div className="p-3.5 rounded-2xl bg-black/30 border border-white/10 space-y-2">
            <code className="block text-xs font-mono-num text-emerald-300 break-all selectable-text" dir="ltr">
              {capBuildCmd}
            </code>
            <button
              type="button"
              onClick={async () => {
                await nativeCopyText(capBuildCmd);
                setCopiedCmd(true);
                setTimeout(() => setCopiedCmd(false), 2000);
              }}
              className="min-h-[38px] px-3 py-1.5 rounded-lg bg-white/10 active:bg-white/20 text-xs font-semibold"
            >
              {copiedCmd ? t.copied : lang === 'ar' ? 'نسخ الأمر' : 'Copy Command'}
            </button>
          </div>
        </div>

        {/* Local Realm DB Sync Store Inspector */}
        <div className="rounded-3xl bg-white dark:bg-[#1E1B2E] border border-slate-200 dark:border-white/10 p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Database className="w-5 h-5 text-[#8B5CF6]" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {lang === 'ar' ? 'جداول Realm DB المحلية على الهاتف' : 'Local Realm DB Tables'}
              </h3>
            </div>

            <button
              type="button"
              onClick={handleExportRealm}
              className="min-h-[40px] px-3 py-1.5 rounded-xl bg-[#8B5CF6] text-white text-xs font-semibold flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? 'نسخة JSON' : 'Export JSON'}</span>
            </button>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-white/10">
            {FADFADAH_REALM_SCHEMAS.map((schema) => {
              const count = realmDB.objects(
                schema.name as Parameters<typeof realmDB.objects>[0]
              ).length;
              return (
                <div key={schema.name} className="py-2.5 flex items-center justify-between gap-4">
                  <span className="text-xs font-bold font-mono-num text-slate-900 dark:text-white">
                    {schema.name}
                  </span>
                  <span className="text-xs font-mono-num font-bold text-[#8B5CF6]">
                    {count} {lang === 'ar' ? 'سجل' : 'docs'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {saveToast && (
          <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800/60 text-xs font-semibold text-emerald-800 dark:text-emerald-200">
            {saveToast}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-5 space-y-5 max-w-2xl mx-auto">
      {/* Identity Card */}
      <div className="rounded-3xl bg-white dark:bg-[#1E1B2E] border border-slate-200 dark:border-white/10 p-6 flex flex-col items-center text-center space-y-3">
        <div className="relative">
          <FramedAvatar avatarUrl={avatarUrl} frameId={frameId} nickname={nickname} size="xl" />
          <input
            ref={avatarUploadRef}
            type="file"
            accept="image/*"
            onChange={handleCustomAvatarUpload}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => avatarUploadRef.current?.click()}
            title={lang === 'ar' ? 'رفع صورة رمزية' : 'Upload custom avatar'}
            className="absolute -bottom-1 -left-1 min-h-[38px] min-w-[38px] rounded-full bg-[#2D1B69] text-white border-2 border-white dark:border-[#1E1B2E] flex items-center justify-center shadow"
          >
            <ImagePlus className="w-4 h-4" />
          </button>
        </div>

        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">{selfUser.nickname}</h2>
          <p className="text-xs font-semibold text-amber-600 dark:text-amber-400 mt-0.5">
            {selfUser.is_premium ? t.premiumBadge : t.freeTierBadge} ·{' '}
            <span className="font-mono-num">{selfUser.points}</span>{' '}
            {lang === 'ar' ? 'نقطة' : 'pts'}
          </p>
        </div>
      </div>

      {/* Profile Editor */}
      <form
        onSubmit={handleSaveProfile}
        className="rounded-3xl bg-white dark:bg-[#1E1B2E] border border-slate-200 dark:border-white/10 p-5 space-y-4"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300">
              {t.nicknameLabel}
            </label>
            <input
              type="text"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              maxLength={24}
              className="w-full h-11 px-3.5 rounded-xl bg-slate-50 dark:bg-[#151221] border border-slate-200 dark:border-white/10 text-sm font-semibold text-slate-900 dark:text-white"
            />
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300">
              {t.customSlugLabel}
            </label>
            <div
              className="flex items-center h-11 px-3 rounded-xl bg-slate-50 dark:bg-[#151221] border border-slate-200 dark:border-white/10"
              dir="ltr"
            >
              <span className="text-xs text-slate-400 font-mono-num">/u/</span>
              <input
                type="text"
                value={slug}
                onChange={(e) => setSlug(e.target.value)}
                maxLength={20}
                className="flex-1 bg-transparent text-xs font-mono-num font-semibold text-slate-900 dark:text-white focus:outline-none"
              />
            </div>
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300">
            {t.countryLabel}
          </label>
          <select
            value={country}
            onChange={(e) => setCountry(e.target.value)}
            className="w-full h-11 px-3.5 rounded-xl bg-slate-50 dark:bg-[#151221] border border-slate-200 dark:border-white/10 text-sm text-slate-900 dark:text-white"
          >
            {AVAILABLE_COUNTRIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>

        <div className="space-y-1.5">
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300">
            {lang === 'ar' ? 'نبذة قصيرة للمطابقة' : 'Short Bio'}
          </label>
          <input
            type="text"
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            maxLength={110}
            className="w-full h-11 px-3.5 rounded-xl bg-slate-50 dark:bg-[#151221] border border-slate-200 dark:border-white/10 text-sm text-slate-900 dark:text-white"
          />
        </div>

        <div className="space-y-3">
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300">
            {t.avatarAndFrames}
          </label>
          <div className="flex items-center gap-2.5 overflow-x-auto pb-1">
            {AVATAR_PRESETS.map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => setAvatarUrl(preset)}
                className={`min-h-[48px] min-w-[48px] rounded-full flex items-center justify-center ${
                  avatarUrl === preset ? 'scale-105 ring-2 ring-[#8B5CF6]' : 'opacity-70'
                }`}
              >
                <FramedAvatar avatarUrl={preset} frameId={0} nickname={preset} size="sm" />
              </button>
            ))}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
            {PROFILE_FRAMES.map((fr) => {
              const unlocked = selfUser.is_premium || selfUser.unlocked_frames.includes(fr.id);
              const selected = frameId === fr.id;
              return (
                <button
                  key={fr.id}
                  type="button"
                  onClick={() => handleSelectFrame(fr.id)}
                  className={`p-3 rounded-2xl border text-start flex items-center gap-2.5 ${
                    selected
                      ? 'border-[#8B5CF6] bg-[#8B5CF6]/10'
                      : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#151221]'
                  }`}
                >
                  <FramedAvatar avatarUrl={avatarUrl} frameId={fr.id} nickname={fr.nameEn} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {lang === 'ar' ? fr.nameAr : fr.nameEn}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                      {unlocked ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-500" />
                          <span>{lang === 'ar' ? 'متاح' : 'Unlocked'}</span>
                        </>
                      ) : fr.premiumOnly ? (
                        <>
                          <Sparkles className="w-3 h-3 text-amber-500" />
                          <span>VIP</span>
                        </>
                      ) : (
                        <>
                          <Lock className="w-3 h-3" />
                          <span className="font-mono-num">{fr.costPoints}</span>
                        </>
                      )}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-2.5">
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300">
            {t.interestsAndLangs}
          </label>
          <div className="flex flex-wrap gap-2">
            {AVAILABLE_INTERESTS.map((item) => {
              const active = interests.includes(item);
              return (
                <button
                  key={item}
                  type="button"
                  onClick={() => toggleInterest(item)}
                  className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap ${
                    active
                      ? 'bg-[#8B5CF6] text-white'
                      : 'bg-slate-100 dark:bg-[#151221] text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {item}
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap gap-2 pt-1">
            {AVAILABLE_LANGUAGES.map((lItem) => {
              const active = languages.includes(lItem);
              return (
                <button
                  key={lItem}
                  type="button"
                  onClick={() => toggleLanguageItem(lItem)}
                  className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap ${
                    active
                      ? 'bg-[#2D1B69] text-white'
                      : 'bg-slate-100 dark:bg-[#151221] text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {lItem}
                </button>
              );
            })}
          </div>
        </div>

        <button
          type="submit"
          className="w-full min-h-[48px] rounded-2xl bg-[#8B5CF6] active:scale-[0.99] text-white text-sm font-bold transition-transform"
        >
          {t.saveProfile}
        </button>

        {saveToast && (
          <p className="text-center text-xs font-semibold text-emerald-600 dark:text-emerald-400">
            {saveToast}
          </p>
        )}
      </form>

      {/* Native Android Settings Rows */}
      <div className="rounded-3xl bg-white dark:bg-[#1E1B2E] border border-slate-200 dark:border-white/10 divide-y divide-slate-100 dark:divide-white/10 overflow-hidden">
        <div className="px-5 min-h-[58px] flex items-center justify-between gap-4">
          <span className="text-sm font-semibold text-slate-900 dark:text-white">{t.darkMode}</span>
          <button
            type="button"
            role="switch"
            aria-checked={settings.theme === 'dark'}
            onClick={onToggleTheme}
            className={`w-12 h-7 rounded-full p-1 transition-colors flex items-center ${
              settings.theme === 'dark'
                ? 'bg-[#8B5CF6] justify-end'
                : 'bg-slate-300 justify-start'
            }`}
          >
            <span className="w-5 h-5 rounded-full bg-white shadow" />
          </button>
        </div>

        <button
          type="button"
          onClick={onToggleLanguage}
          className="w-full px-5 min-h-[58px] flex items-center justify-between gap-4 active:bg-slate-50 dark:active:bg-white/5"
        >
          <span className="text-sm font-semibold text-slate-900 dark:text-white">
            {t.languageToggle}
          </span>
          <span className="text-xs font-bold text-[#8B5CF6]">
            {settings.language === 'ar' ? 'العربية (RTL)' : 'English (LTR)'}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setSubView('monetization')}
          className="w-full px-5 min-h-[58px] flex items-center justify-between gap-4 active:bg-slate-50 dark:active:bg-white/5"
        >
          <span className="text-sm font-semibold text-slate-900 dark:text-white">
            {t.subscriptionsAndPoints}
          </span>
          <DisclosureChevron className="w-4 h-4 text-slate-400" />
        </button>

        <button
          type="button"
          onClick={() => setSubView('realm_android')}
          className="w-full px-5 min-h-[58px] flex items-center justify-between gap-4 active:bg-slate-50 dark:active:bg-white/5"
        >
          <span className="text-sm font-semibold text-slate-900 dark:text-white">
            {lang === 'ar'
              ? 'إعدادات السيرفر وتصدير APK للأندرويد'
              : 'Server URL & Android APK Build'}
          </span>
          <DisclosureChevron className="w-4 h-4 text-slate-400" />
        </button>

        <button
          type="button"
          onClick={() => setShowDeleteConfirm(true)}
          className="w-full px-5 min-h-[58px] flex items-center justify-between gap-4 active:bg-rose-50 dark:active:bg-rose-950/30 text-rose-600 dark:text-rose-400"
        >
          <span className="text-sm font-semibold flex items-center gap-2">
            <Trash2 className="w-4 h-4" />
            <span>{t.deleteAccount}</span>
          </span>
          <DisclosureChevron className="w-4 h-4" />
        </button>
      </div>

      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-[#1E1B2E] border border-slate-200 dark:border-white/10 p-6 space-y-4">
            <h3 className="text-base font-bold text-rose-600 dark:text-rose-400">
              {t.deleteAccount}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {lang === 'ar'
                ? 'سيتم مسح حسابك ورابطك الشخصي وجميع محادثاتك نهائياً من السيرفر ومن قاعدة بيانات Realm على هاتفك.'
                : 'Your account, link, and chats will be deleted permanently from both the server and Local Realm DB.'}
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(false)}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-100 dark:bg-white/10 text-xs font-semibold text-slate-700 dark:text-slate-200"
              >
                {lang === 'ar' ? 'تراجع' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handlePermanentDelete}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-rose-600 text-xs font-semibold text-white"
              >
                {lang === 'ar' ? 'حذف نهائي' : 'Delete Permanently'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
