import {
  generateUUID,
  PremiumPlan,
  realmDB,
  RealmChatRoom,
  RealmMessage,
  RealmPersonalLink,
  RealmPublicVent,
  RealmUser,
  MediaType,
} from '../db/realmLocalDB';
import { isRunningInsideNativeAndroid, triggerLightHaptic } from './androidNative';

export interface LiveMatchCandidate {
  peer: RealmUser;
  inQueue: boolean;
  similarityScore: number;
}

type ConnectionState = 'connecting' | 'connected' | 'offline';

class FadfadahNetworkClient {
  private ws: WebSocket | null = null;
  private reconnectTimer: number | null = null;
  private connectionState: ConnectionState = 'connecting';
  private onlineCount = 1;
  private queueSize = 0;
  private matchCandidates: LiveMatchCandidate[] = [];
  private typingUsersByRoom = new Map<string, boolean>();
  private stateListeners = new Set<() => void>();
  private manualClose = false;

  getServerBaseUrl(): string {
    const customUrl = realmDB.getSettings().custom_server_url?.trim();
    if (customUrl) {
      return customUrl.replace(/\/+$/, '');
    }
    const envUrl = (import.meta.env.VITE_API_SERVER_URL as string | undefined)?.trim();
    if (envUrl) {
      return envUrl.replace(/\/+$/, '');
    }
    if (isRunningInsideNativeAndroid()) {
      // Standard Android Studio Emulator host loopback to the developer's PC port 3000
      return 'http://10.0.2.2:3000';
    }
    return window.location.origin;
  }

  getShareBaseUrl(): string {
    return this.getServerBaseUrl();
  }

  getConnectionState(): ConnectionState {
    return this.connectionState;
  }

  getOnlineStats(): { onlineCount: number; queueSize: number } {
    return { onlineCount: this.onlineCount, queueSize: this.queueSize };
  }

  getMatchCandidates(): LiveMatchCandidate[] {
    return this.matchCandidates;
  }

  isPeerTypingInRoom(roomId: string): boolean {
    return Boolean(this.typingUsersByRoom.get(roomId));
  }

  subscribe(cb: () => void): () => void {
    this.stateListeners.add(cb);
    return () => {
      this.stateListeners.delete(cb);
    };
  }

  private emitState(): void {
    for (const cb of this.stateListeners) {
      cb();
    }
  }

  private getAuthHeaders(): Record<string, string> {
    const token = realmDB.getSettings().auth_token;
    return token
      ? {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        }
      : { 'Content-Type': 'application/json' };
  }

  async bootstrapSessionAndSync(): Promise<void> {
    await realmDB.open();
    const settings = realmDB.getSettings();

    try {
      if (!settings.auth_token) {
        await this.registerFreshDeviceAccount();
      } else {
        const ok = await this.pullFullSync();
        if (!ok) {
          // Token expired or server DB was wiped -> register cleanly
          await this.registerFreshDeviceAccount();
          await this.pullFullSync();
        }
      }
      this.connectWebSocket();
    } catch {
      // Offline launch: Android app continues working using cached Local Realm DB!
      this.connectionState = 'offline';
      this.emitState();
      this.scheduleReconnect();
    }
  }

  private async registerFreshDeviceAccount(): Promise<void> {
    const base = this.getServerBaseUrl();
    const res = await fetch(`${base}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
    if (!res.ok) throw new Error('Registration failed');
    const data = (await res.json()) as {
      authToken: string;
      selfUser: RealmUser;
      personalLink: RealmPersonalLink;
    };

    const currentSettings = realmDB.getSettings();
    await realmDB.write((tx) => {
      tx.create('app_settings', {
        ...currentSettings,
        auth_token: data.authToken,
      });
      tx.create('users', { ...data.selfUser, is_self: true });
      tx.create('personal_links', data.personalLink);
    });
  }

  async pullFullSync(): Promise<boolean> {
    const base = this.getServerBaseUrl();
    const res = await fetch(`${base}/api/sync`, {
      method: 'GET',
      headers: this.getAuthHeaders(),
    });
    if (res.status === 401) {
      return false;
    }
    if (!res.ok) {
      throw new Error('Sync error');
    }

    const data = (await res.json()) as {
      selfUser: RealmUser;
      personalLink?: RealmPersonalLink;
      rooms: RealmChatRoom[];
      messages: RealmMessage[];
      peers: Array<Omit<RealmUser, 'is_self'>>;
      vents: RealmPublicVent[];
    };

    await realmDB.write((tx) => {
      // Reconcile users
      for (const existingU of realmDB.objects('users')) {
        tx.delete('users', existingU.id);
      }
      tx.create('users', { ...data.selfUser, is_self: true });
      for (const p of data.peers) {
        tx.create('users', {
          ...p,
          premium_plan: p.is_premium ? 'monthly' : 'free',
          points: 0,
          unlocked_frames: [0, 1],
          blocked_user_ids: [],
          daily_random_count: 0,
          last_random_date: '',
          is_self: false,
        });
      }

      if (data.personalLink) {
        tx.create('personal_links', data.personalLink);
      }

      // Reconcile rooms
      for (const existingR of realmDB.objects('chat_rooms')) {
        tx.delete('chat_rooms', existingR.id);
      }
      for (const r of data.rooms) {
        tx.create('chat_rooms', r);
      }

      // Reconcile messages
      for (const existingM of realmDB.objects('messages')) {
        tx.delete('messages', existingM.id);
      }
      for (const m of data.messages) {
        tx.create('messages', m);
      }

      // Reconcile public vents
      for (const existingV of realmDB.objects('public_vents')) {
        tx.delete('public_vents', existingV.id);
      }
      for (const v of data.vents) {
        tx.create('public_vents', v);
      }
    });

    return true;
  }

  connectWebSocket(): void {
    const token = realmDB.getSettings().auth_token;
    if (!token) return;

    if (this.ws) {
      this.manualClose = true;
      this.ws.close();
      this.ws = null;
    }
    this.manualClose = false;

    const httpBase = this.getServerBaseUrl();
    const wsBase = httpBase.replace(/^http/i, 'ws');
    const wsUrl = `${wsBase}/ws?token=${encodeURIComponent(token)}`;

    this.connectionState = 'connecting';
    this.emitState();

    try {
      const socket = new WebSocket(wsUrl);
      this.ws = socket;

      socket.onopen = () => {
        if (this.reconnectTimer) {
          window.clearTimeout(this.reconnectTimer);
          this.reconnectTimer = null;
        }
        this.connectionState = 'connected';
        this.emitState();
      };

      socket.onmessage = async (event) => {
        try {
          const payload = JSON.parse(String(event.data)) as Record<string, unknown>;
          await this.handleServerSocketEvent(payload);
        } catch {
          // Ignore malformed event
        }
      };

      socket.onclose = () => {
        if (this.ws === socket) {
          this.ws = null;
        }
        if (!this.manualClose) {
          this.connectionState = 'offline';
          this.emitState();
          this.scheduleReconnect();
        }
      };

      socket.onerror = () => {
        socket.close();
      };
    } catch {
      this.connectionState = 'offline';
      this.emitState();
      this.scheduleReconnect();
    }
  }

  private scheduleReconnect(): void {
    if (this.reconnectTimer) return;
    this.reconnectTimer = window.setTimeout(async () => {
      this.reconnectTimer = null;
      try {
        await this.bootstrapSessionAndSync();
      } catch {
        this.scheduleReconnect();
      }
    }, 3500);
  }

  private async handleServerSocketEvent(ev: Record<string, unknown>): Promise<void> {
    const type = String(ev.type || '');
    const self = realmDB.findSelfUser();

    if (type === 'presence:online_users') {
      const users = (ev.users as Array<RealmUser>) || [];
      this.onlineCount = Math.max(1, users.length);
      const onlineIds = new Set(users.map((u) => u.id));
      await realmDB.write((tx) => {
        for (const existing of realmDB.objects('users')) {
          if (!existing.is_self) {
            tx.create('users', { ...existing, is_online: onlineIds.has(existing.id) });
          }
        }
        for (const u of users) {
          if (self && u.id === self.id) continue;
          const prev = realmDB.objectForPrimaryKey('users', u.id);
          tx.create('users', {
            ...(prev ?? {
              premium_plan: u.is_premium ? 'monthly' : 'free',
              points: 0,
              unlocked_frames: [0, 1],
              blocked_user_ids: [],
              daily_random_count: 0,
              last_random_date: '',
            }),
            ...u,
            is_self: false,
            is_online: true,
          });
        }
      });
      this.emitState();
    } else if (type === 'peer:updated') {
      const peer = ev.peer as RealmUser | undefined;
      if (peer && (!self || peer.id !== self.id)) {
        await realmDB.write((tx) => {
          const prev = realmDB.objectForPrimaryKey('users', peer.id);
          tx.create('users', {
            ...(prev ?? {
              premium_plan: peer.is_premium ? 'monthly' : 'free',
              points: 0,
              unlocked_frames: [0, 1],
              blocked_user_ids: [],
              daily_random_count: 0,
              last_random_date: '',
            }),
            ...peer,
            is_self: false,
          });
        });
      }
    } else if (type === 'link:updated') {
      const link = ev.personalLink as RealmPersonalLink | undefined;
      if (link) {
        await realmDB.write((tx) => {
          tx.create('personal_links', link);
        });
      }
    } else if (type === 'room:upsert') {
      const room = ev.room as RealmChatRoom | undefined;
      const peer = ev.peer as RealmUser | undefined;
      const msg = ev.message as RealmMessage | undefined;
      await realmDB.write((tx) => {
        if (peer && (!self || peer.id !== self.id)) {
          const prev = realmDB.objectForPrimaryKey('users', peer.id);
          tx.create('users', {
            ...(prev ?? {
              premium_plan: peer.is_premium ? 'monthly' : 'free',
              points: 0,
              unlocked_frames: [0, 1],
              blocked_user_ids: [],
              daily_random_count: 0,
              last_random_date: '',
            }),
            ...peer,
            is_self: false,
          });
        }
        if (room) tx.create('chat_rooms', room);
        if (msg) tx.create('messages', msg);
      });
      await triggerLightHaptic();
    } else if (type === 'room:deleted') {
      const roomId = String(ev.roomId || '');
      if (roomId) {
        await realmDB.write((tx) => {
          for (const m of realmDB.objects('messages').filter((x) => x.room_id === roomId)) {
            tx.delete('messages', m.id);
          }
          tx.delete('chat_rooms', roomId);
        });
      }
    } else if (type === 'message:created') {
      const msg = ev.message as RealmMessage | undefined;
      const room = ev.room as RealmChatRoom | undefined;
      const senderPeer = ev.senderPeer as RealmUser | undefined;
      if (room) {
        this.typingUsersByRoom.set(room.id, false);
      }
      await realmDB.write((tx) => {
        if (senderPeer && (!self || senderPeer.id !== self.id)) {
          const prev = realmDB.objectForPrimaryKey('users', senderPeer.id);
          tx.create('users', {
            ...(prev ?? {
              premium_plan: senderPeer.is_premium ? 'monthly' : 'free',
              points: 0,
              unlocked_frames: [0, 1],
              blocked_user_ids: [],
              daily_random_count: 0,
              last_random_date: '',
            }),
            ...senderPeer,
            is_self: false,
          });
        }
        if (room) tx.create('chat_rooms', room);
        if (msg) tx.create('messages', msg);
      });
      if (msg && self && msg.sender_id !== self.id) {
        await triggerLightHaptic();
      }
      this.emitState();
    } else if (type === 'messages:read') {
      const roomId = String(ev.roomId || '');
      const ids = new Set((ev.messageIds as string[]) || []);
      await realmDB.write((tx) => {
        for (const m of realmDB.objects('messages')) {
          if (m.room_id === roomId && ids.has(m.id)) {
            tx.create('messages', { ...m, status: 'READ' });
          }
        }
      });
    } else if (type === 'typing') {
      const roomId = String(ev.roomId || '');
      this.typingUsersByRoom.set(roomId, Boolean(ev.isTyping));
      this.emitState();
    } else if (type === 'match:candidates') {
      const rawList = (ev.candidates as Array<LiveMatchCandidate>) || [];
      this.matchCandidates = rawList.map((c) => {
        const prev = realmDB.objectForPrimaryKey('users', c.peer.id);
        return {
          ...c,
          peer: {
            ...(prev ?? {
              premium_plan: c.peer.is_premium ? 'monthly' : 'free',
              points: 0,
              unlocked_frames: [0, 1],
              blocked_user_ids: [],
              daily_random_count: 0,
              last_random_date: '',
            }),
            ...c.peer,
            is_self: false,
          },
        };
      });
      this.queueSize = Number(ev.queueSize) || 0;
      this.onlineCount = Math.max(1, Number(ev.onlineCount) || 1);
      this.emitState();
    } else if (type === 'vent:upsert') {
      const vent = ev.vent as Omit<RealmPublicVent, 'liked_by_me'> | undefined;
      const authorPeer = ev.authorPeer as RealmUser | undefined;
      if (vent) {
        await realmDB.write((tx) => {
          if (authorPeer && (!self || authorPeer.id !== self.id)) {
            const prev = realmDB.objectForPrimaryKey('users', authorPeer.id);
            tx.create('users', {
              ...(prev ?? {
                premium_plan: authorPeer.is_premium ? 'monthly' : 'free',
                points: 0,
                unlocked_frames: [0, 1],
                blocked_user_ids: [],
                daily_random_count: 0,
                last_random_date: '',
              }),
              ...authorPeer,
              is_self: false,
            });
          }
          const existing = realmDB.objectForPrimaryKey('public_vents', vent.id);
          tx.create('public_vents', {
            ...vent,
            liked_by_me: existing?.liked_by_me ?? false,
          });
        });
      }
    } else if (type === 'vent:likes_updated') {
      const ventId = String(ev.ventId || '');
      const likesCount = Number(ev.likes_count) || 0;
      const existing = realmDB.objectForPrimaryKey('public_vents', ventId);
      if (existing) {
        await realmDB.write((tx) => {
          tx.create('public_vents', { ...existing, likes_count: likesCount });
        });
      }
    } else if (type === 'sync:needed') {
      await this.pullFullSync();
    }
  }

  // ============================================================================
  // CLIENT API ACTIONS
  // ============================================================================

  joinMatchmakingQueue(countryFilter: string, langFilter: string): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'match:join_queue',
          countryFilter,
          langFilter,
        })
      );
    }
  }

  leaveMatchmakingQueue(): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'match:leave_queue' }));
    }
  }

  sendTypingIndicator(roomId: string, isTyping: boolean): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'typing', roomId, isTyping }));
    }
  }

  async updateCustomServerUrl(newUrl: string): Promise<boolean> {
    const clean = newUrl.trim().replace(/\/+$/, '');
    const settings = realmDB.getSettings();
    await realmDB.write((tx) => {
      tx.create('app_settings', {
        ...settings,
        custom_server_url: clean,
        auth_token: '',
      });
    });
    try {
      await this.bootstrapSessionAndSync();
      return this.connectionState !== 'offline';
    } catch {
      return false;
    }
  }

  async updateProfile(payload: {
    nickname: string;
    slug: string;
    country: string;
    bio: string;
    avatar_url: string;
    frame_id: number;
    interests: string[];
    languages: string[];
  }): Promise<{ ok: boolean; error?: string }> {
    const res = await fetch(`${this.getServerBaseUrl()}/api/profile`, {
      method: 'PUT',
      headers: this.getAuthHeaders(),
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) {
      return { ok: false, error: data.error || 'تعذر حفظ التعديلات.' };
    }
    await realmDB.write((tx) => {
      tx.create('users', { ...data.selfUser, is_self: true });
      if (data.personalLink) {
        tx.create('personal_links', data.personalLink);
      }
    });
    return { ok: true };
  }

  async fetchPublicLinkInfo(slug: string): Promise<{
    slug: string;
    visits_count: number;
    targetUser: RealmUser;
  } | null> {
    try {
      const res = await fetch(
        `${this.getServerBaseUrl()}/api/links/${encodeURIComponent(slug)}`
      );
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  }

  async sendSecretLinkMessage(
    slug: string,
    payload: { content: string; senderAlias: string; senderAvatar: string }
  ): Promise<{ ok: boolean; roomId?: string; error?: string }> {
    const res = await fetch(
      `${this.getServerBaseUrl()}/api/links/${encodeURIComponent(slug)}/send`,
      {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify(payload),
      }
    );
    const data = await res.json();
    if (!res.ok) {
      return { ok: false, error: data.error || 'تعذر إرسال الرسالة.' };
    }

    // If visitor was issued a new account token (e.g. external visitor or self-testing in fresh tab), persist & sync!
    if (data.issuedAuthToken && data.issuedSelfUser) {
      const s = realmDB.getSettings();
      if (!s.auth_token) {
        await realmDB.write((tx) => {
          tx.create('app_settings', { ...s, auth_token: data.issuedAuthToken });
          tx.create('users', { ...data.issuedSelfUser, is_self: true });
          if (data.issuedPersonalLink) {
            tx.create('personal_links', data.issuedPersonalLink);
          }
        });
        this.connectWebSocket();
      }
    }

    await realmDB.write((tx) => {
      if (data.recipientPeer) {
        const self = realmDB.findSelfUser();
        if (!self || data.recipientPeer.id !== self.id) {
          tx.create('users', {
            premium_plan: 'free',
            points: 0,
            unlocked_frames: [0, 1],
            blocked_user_ids: [],
            daily_random_count: 0,
            last_random_date: '',
            ...data.recipientPeer,
            is_self: false,
          });
        }
      }
      if (data.room) tx.create('chat_rooms', data.room);
      if (data.message) tx.create('messages', data.message);
    });

    await triggerLightHaptic();
    return { ok: true, roomId: data.room?.id };
  }

  async requestRandomMatch(
    targetPeerId: string,
    introText?: string
  ): Promise<{ ok: boolean; room?: RealmChatRoom; quotaReached?: boolean; error?: string }> {
    const res = await fetch(`${this.getServerBaseUrl()}/api/match/request`, {
      method: 'POST',
      headers: this.getAuthHeaders(),
      body: JSON.stringify({ targetPeerId, introText }),
    });
    const data = await res.json();
    if (res.status === 429) {
      return { ok: false, quotaReached: true };
    }
    if (!res.ok) {
      return { ok: false, error: data.error || 'تعذر إرسال طلب المحادثة.' };
    }

    await realmDB.write((tx) => {
      if (data.selfUser) tx.create('users', { ...data.selfUser, is_self: true });
      if (data.peer) {
        tx.create('users', {
          premium_plan: data.peer.is_premium ? 'monthly' : 'free',
          points: 0,
          unlocked_frames: [0, 1],
          blocked_user_ids: [],
          daily_random_count: 0,
          last_random_date: '',
          ...data.peer,
          is_self: false,
        });
      }
      if (data.room) tx.create('chat_rooms', data.room);
      if (data.message) tx.create('messages', data.message);
    });

    await triggerLightHaptic();
    return { ok: true, room: data.room };
  }

  async respondToChatRequest(roomId: string, action: 'ACCEPT' | 'REJECT'): Promise<void> {
    const res = await fetch(
      `${this.getServerBaseUrl()}/api/rooms/${encodeURIComponent(roomId)}/respond`,
      {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify({ action }),
      }
    );
    const data = await res.json();
    if (action === 'REJECT' || data.deleted) {
      await realmDB.write((tx) => {
        for (const m of realmDB.objects('messages').filter((x) => x.room_id === roomId)) {
          tx.delete('messages', m.id);
        }
        tx.delete('chat_rooms', roomId);
      });
    } else if (data.room) {
      await realmDB.write((tx) => {
        tx.create('chat_rooms', data.room);
      });
    }
  }

  async sendMessage(
    roomId: string,
    params: { content: string; media_url?: string; media_type?: MediaType }
  ): Promise<{ ok: boolean; isFrozen?: boolean; reason?: string }> {
    const self = realmDB.findSelfUser();
    if (!self) return { ok: false };

    const msgId = `msg-${generateUUID().slice(0, 8)}`;
    const now = Date.now();

    // Optimistic local write to Realm DB for 0ms Android responsiveness
    const optimisticMsg: RealmMessage = {
      id: msgId,
      room_id: roomId,
      sender_id: self.id,
      content: params.content,
      media_url: params.media_url || '',
      media_type: params.media_type || 'text',
      ai_flag_score: 0,
      ai_flag_reason: '',
      is_frozen: false,
      status: 'SENT',
      created_at: now,
    };

    await realmDB.write((tx) => {
      tx.create('messages', optimisticMsg);
      const room = realmDB.objectForPrimaryKey('chat_rooms', roomId);
      if (room) {
        tx.create('chat_rooms', {
          ...room,
          last_message_preview: params.content,
          last_message_at: now,
        });
      }
    });

    try {
      const res = await fetch(
        `${this.getServerBaseUrl()}/api/rooms/${encodeURIComponent(roomId)}/messages`,
        {
          method: 'POST',
          headers: this.getAuthHeaders(),
          body: JSON.stringify({
            id: msgId,
            content: params.content,
            media_url: params.media_url || '',
            media_type: params.media_type || 'text',
          }),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        await realmDB.write((tx) => tx.delete('messages', msgId));
        return { ok: false, reason: data.error };
      }

      await realmDB.write((tx) => {
        if (data.message) tx.create('messages', data.message);
        if (data.room) tx.create('chat_rooms', data.room);
      });

      if (data.message?.is_frozen) {
        return { ok: true, isFrozen: true, reason: data.message.ai_flag_reason };
      }
      await triggerLightHaptic();
      return { ok: true };
    } catch {
      return { ok: false, reason: 'انقطع الاتصال بالسيرفر.' };
    }
  }

  async markRoomRead(roomId: string): Promise<void> {
    const room = realmDB.objectForPrimaryKey('chat_rooms', roomId);
    if (room && room.unread_count > 0) {
      await realmDB.write((tx) => {
        tx.create('chat_rooms', { ...room, unread_count: 0 });
      });
    }
    try {
      await fetch(`${this.getServerBaseUrl()}/api/rooms/${encodeURIComponent(roomId)}/read`, {
        method: 'POST',
        headers: this.getAuthHeaders(),
      });
    } catch {
      // Reconciles on next sync
    }
  }

  async blockPeer(roomId: string): Promise<void> {
    await fetch(`${this.getServerBaseUrl()}/api/rooms/${encodeURIComponent(roomId)}/block`, {
      method: 'POST',
      headers: this.getAuthHeaders(),
    });
    const self = realmDB.findSelfUser();
    const room = realmDB.objectForPrimaryKey('chat_rooms', roomId);
    if (self && room) {
      const peerId = room.participant_a === self.id ? room.participant_b : room.participant_a;
      await realmDB.write((tx) => {
        tx.create('chat_rooms', { ...room, status: 'BLOCKED' });
        tx.create('users', {
          ...self,
          blocked_user_ids: Array.from(new Set([...self.blocked_user_ids, peerId])),
        });
      });
    }
  }

  async submitReport(
    roomId: string,
    reportedUserId: string,
    reason: string
  ): Promise<string> {
    const res = await fetch(`${this.getServerBaseUrl()}/api/reports`, {
      method: 'POST',
      headers: this.getAuthHeaders(),
      body: JSON.stringify({ roomId, reportedUserId, reason }),
    });
    const data = await res.json();
    if (data.report) {
      await realmDB.write((tx) => {
        tx.create('reports_moderation', data.report);
      });
      return data.report.ai_summary;
    }
    return 'تم حفظ البلاغ في سجل الإشراف.';
  }

  async publishVent(topic: string, content: string): Promise<{ ok: boolean; error?: string }> {
    const res = await fetch(`${this.getServerBaseUrl()}/api/vents`, {
      method: 'POST',
      headers: this.getAuthHeaders(),
      body: JSON.stringify({ topic, content }),
    });
    const data = await res.json();
    if (!res.ok) {
      return { ok: false, error: data.error || 'تعذر نشر الفضفضة.' };
    }
    await realmDB.write((tx) => {
      tx.create('public_vents', data.vent);
    });
    await triggerLightHaptic();
    return { ok: true };
  }

  async toggleLikeVent(ventId: string): Promise<void> {
    const res = await fetch(
      `${this.getServerBaseUrl()}/api/vents/${encodeURIComponent(ventId)}/like`,
      {
        method: 'POST',
        headers: this.getAuthHeaders(),
      }
    );
    if (!res.ok) return;
    const data = await res.json();
    const existing = realmDB.objectForPrimaryKey('public_vents', ventId);
    if (existing) {
      await realmDB.write((tx) => {
        tx.create('public_vents', {
          ...existing,
          likes_count: data.likes_count,
          liked_by_me: data.liked_by_me,
        });
      });
    }
  }

  async activatePlan(plan: PremiumPlan, bonusPoints: number): Promise<void> {
    const res = await fetch(`${this.getServerBaseUrl()}/api/monetization/plan`, {
      method: 'POST',
      headers: this.getAuthHeaders(),
      body: JSON.stringify({ plan, bonusPoints }),
    });
    if (!res.ok) return;
    const data = await res.json();
    if (data.selfUser) {
      await realmDB.write((tx) => {
        tx.create('users', { ...data.selfUser, is_self: true });
      });
    }
  }

  async modifyPoints(params: {
    deltaPoints?: number;
    unlockFrameId?: number;
    unlockExtraQuota?: boolean;
  }): Promise<boolean> {
    const res = await fetch(`${this.getServerBaseUrl()}/api/monetization/points`, {
      method: 'POST',
      headers: this.getAuthHeaders(),
      body: JSON.stringify(params),
    });
    if (!res.ok) return false;
    const data = await res.json();
    if (data.selfUser) {
      await realmDB.write((tx) => {
        tx.create('users', { ...data.selfUser, is_self: true });
      });
    }
    return true;
  }

  async deleteAccountPermanently(): Promise<void> {
    try {
      await fetch(`${this.getServerBaseUrl()}/api/account`, {
        method: 'DELETE',
        headers: this.getAuthHeaders(),
      });
    } catch {
      // Proceed to wipe local Realm DB as well
    }
    await realmDB.clearAllUserDataPreservePreferences();
    await this.bootstrapSessionAndSync();
  }
}

export const fadfadahClient = new FadfadahNetworkClient();
