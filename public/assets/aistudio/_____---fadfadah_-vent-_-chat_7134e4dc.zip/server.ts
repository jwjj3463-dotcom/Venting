import 'dotenv/config';
import crypto from 'crypto';
import express from 'express';
import type { Request, Response, NextFunction } from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';
import {
  computeServerEmbedding,
  cosineSimilarityServer,
  serverDB,
  type ChatRoomStatus,
  type MediaType,
  type PremiumPlan,
  type ServerChatRoom,
  type ServerUserRecord,
} from './server/fadfadahServerDB.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Optional Gemini AI upgrade (server works 100% standalone without any API key too!)
function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey.trim() === '') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Standalone Built-in Arabic & English Safety Filter
const SEVERE_PATTERNS = [
  /انتحار|أقتلك|سأقتلك|تهديد|ابتزاز|مخدرات/i,
  /\b(kill you|suicide|blackmail|doxx|bomb)\b/i,
  /\b(\+?\d[\d\s-]{8,14}\d)\b/,
];
const PROFANITY_PATTERNS = [
  /غبي|أحمق|حيوان|تافه|لعنة|قذر/i,
  /\b(idiot|stupid|loser|shut up|trash)\b/i,
];

interface ModerationVerdict {
  flagScore: number;
  isFrozen: boolean;
  reasonAr: string;
  reasonEn: string;
}

async function moderateServerContent(
  text: string,
  imageBase64?: string,
  mimeType?: string
): Promise<ModerationVerdict> {
  const clean = text.trim();
  for (const pat of SEVERE_PATTERNS) {
    if (pat.test(clean)) {
      return {
        flagScore: 0.92,
        isFrozen: true,
        reasonAr: 'تم تجميد الرسالة لاحتوائها على تهديد أو مشاركة أرقام وبيانات حساسة.',
        reasonEn: 'Message frozen due to threat or sensitive personal contact information.',
      };
    }
  }
  for (const pat of PROFANITY_PATTERNS) {
    if (pat.test(clean)) {
      return {
        flagScore: 0.79,
        isFrozen: true,
        reasonAr: 'تم حجب الرسالة لاحتوائها على ألفاظ مسيئة مخالفة لإرشادات فضفضة.',
        reasonEn: 'Message blocked due to offensive language.',
      };
    }
  }

  const ai = getAiClient();
  if (!ai) {
    return { flagScore: 0.02, isFrozen: false, reasonAr: '', reasonEn: '' };
  }

  try {
    const parts: Array<{ text: string } | { inlineData: { mimeType: string; data: string } }> = [];
    if (imageBase64 && mimeType) {
      const rawData = imageBase64.includes(',') ? imageBase64.split(',')[1] : imageBase64;
      parts.push({ inlineData: { mimeType, data: rawData } });
    }
    parts.push({
      text: `Analyze this anonymous chat content for harassment, threats, explicit abuse, or sensitive personal phone/address sharing. Normal sadness or emotional venting is SAFE. Text: "${clean}"`,
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: { parts },
      config: {
        abortSignal: AbortSignal.timeout(2500),
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            flagScore: { type: Type.NUMBER },
            isFrozen: { type: Type.BOOLEAN },
            reasonAr: { type: Type.STRING },
            reasonEn: { type: Type.STRING },
          },
          required: ['flagScore', 'isFrozen', 'reasonAr', 'reasonEn'],
        },
      },
    });
    const parsed = JSON.parse((response.text ?? '{}').trim()) as Partial<ModerationVerdict>;
    if (typeof parsed.flagScore === 'number') {
      return {
        flagScore: Number(parsed.flagScore.toFixed(2)),
        isFrozen: Boolean(parsed.isFrozen || parsed.flagScore >= 0.72),
        reasonAr: parsed.reasonAr ?? '',
        reasonEn: parsed.reasonEn ?? '',
      };
    }
  } catch {
    // Fallback cleanly to standalone local verdict
  }

  return { flagScore: 0.02, isFrozen: false, reasonAr: '', reasonEn: '' };
}

function extractBearerToken(req: Request): string | undefined {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) return undefined;
  return header.slice(7).trim();
}

function formatRoomForUser(room: ServerChatRoom, viewerId: string) {
  return {
    id: room.id,
    type: room.type,
    participant_a: room.participant_a,
    participant_b: room.participant_b,
    status: room.status,
    unread_count: room.participant_a === viewerId ? room.unread_a : room.unread_b,
    last_message_preview: room.last_message_preview,
    last_message_at: room.last_message_at,
    created_at: room.created_at,
  };
}

async function startServer() {
  await serverDB.init();

  const app = express();
  const httpServer = http.createServer(app);

  // Full CORS support for Capacitor Android APK (https://localhost, capacitor://localhost, LAN IPs)
  app.use((req: Request, res: Response, next: NextFunction) => {
    const origin = req.headers.origin || '*';
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
    next();
  });

  app.use(express.json({ limit: '6mb' }));

  // Live WebSocket Connection Registry & Real Matchmaking Queue
  const activeSockets = new Map<string, Set<WebSocket>>(); // userId -> sockets
  const matchQueue = new Map<
    string,
    { countryFilter: string; langFilter: string; joinedAt: number }
  >();

  function isUserOnline(userId: string): boolean {
    const set = activeSockets.get(userId);
    return Boolean(set && set.size > 0);
  }

  function sendToUser(userId: string, eventPayload: Record<string, unknown>): void {
    const set = activeSockets.get(userId);
    if (!set) return;
    const raw = JSON.stringify(eventPayload);
    for (const ws of set) {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(raw);
      }
    }
  }

  function broadcastAll(eventPayload: Record<string, unknown>): void {
    const raw = JSON.stringify(eventPayload);
    for (const set of activeSockets.values()) {
      for (const ws of set) {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(raw);
        }
      }
    }
  }

  function broadcastOnlinePresence(): void {
    const onlineUsers = Array.from(activeSockets.keys())
      .filter((uid) => isUserOnline(uid))
      .map((uid) => serverDB.users.get(uid))
      .filter((u): u is ServerUserRecord => Boolean(u))
      .map((u) => serverDB.toPublicUser(u, true));

    broadcastAll({
      type: 'presence:online_users',
      users: onlineUsers,
    });
  }

  function pushLiveCandidatesToUser(viewer: ServerUserRecord, countryFilter: string, langFilter: string): void {
    const candidates = Array.from(serverDB.users.values())
      .filter((u) => {
        if (u.id === viewer.id) return false;
        if (viewer.blocked_user_ids.includes(u.id) || u.blocked_user_ids.includes(viewer.id)) {
          return false;
        }
        if (countryFilter !== 'ALL' && u.country !== countryFilter) return false;
        if (langFilter !== 'ALL' && !u.languages.includes(langFilter)) return false;
        // Prefer currently online users or users in matchmaking queue, plus registered real accounts
        return true;
      })
      .map((peer) => {
        const online = isUserOnline(peer.id);
        const inQueue = matchQueue.has(peer.id);
        const sim = cosineSimilarityServer(viewer.embedding_vector, peer.embedding_vector);
        const priorityScore =
          sim * 0.65 +
          (inQueue ? 0.25 : 0) +
          (online ? 0.12 : 0) +
          (peer.is_premium ? 0.05 : 0);
        return {
          peer: serverDB.toPublicUser(peer, online),
          inQueue,
          similarityScore: Number(Math.min(0.99, Math.max(0.4, priorityScore)).toFixed(2)),
        };
      })
      .sort((a, b) => b.similarityScore - a.similarityScore)
      .slice(0, 30);

    sendToUser(viewer.id, {
      type: 'match:candidates',
      candidates,
      queueSize: matchQueue.size,
      onlineCount: activeSockets.size,
    });
  }

  // WebSocket Server mounted on /ws (coexists cleanly with HTTP & Vite on port 3000)
  const wss = new WebSocketServer({ noServer: true });

  httpServer.on('upgrade', (request, socket, head) => {
    const reqUrl = new URL(request.url || '/', `http://${request.headers.host || 'localhost'}`);
    if (reqUrl.pathname === '/ws') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    }
    // Other upgrade paths (such as Vite dev client in non-prod) pass through untouched
  });

  wss.on('connection', (ws: WebSocket, request: http.IncomingMessage) => {
    const reqUrl = new URL(request.url || '/', `http://${request.headers.host || 'localhost'}`);
    const token = reqUrl.searchParams.get('token') || undefined;
    const user = serverDB.authenticateToken(token);

    if (!user) {
      ws.close(4001, 'Unauthorized');
      return;
    }

    user.last_seen_at = Date.now();
    if (!activeSockets.has(user.id)) {
      activeSockets.set(user.id, new Set());
    }
    activeSockets.get(user.id)!.add(ws);
    broadcastOnlinePresence();

    ws.on('message', (rawBuf) => {
      try {
        const msg = JSON.parse(String(rawBuf)) as {
          type: string;
          roomId?: string;
          isTyping?: boolean;
          countryFilter?: string;
          langFilter?: string;
        };

        const freshUser = serverDB.users.get(user.id);
        if (!freshUser) return;

        if (msg.type === 'typing' && msg.roomId) {
          const room = serverDB.chatRooms.get(msg.roomId);
          if (!room || room.status !== 'ACCEPTED') return;
          if (room.participant_a !== freshUser.id && room.participant_b !== freshUser.id) return;
          const peerId =
            room.participant_a === freshUser.id ? room.participant_b : room.participant_a;
          sendToUser(peerId, {
            type: 'typing',
            roomId: room.id,
            userId: freshUser.id,
            isTyping: Boolean(msg.isTyping),
          });
        } else if (msg.type === 'match:join_queue') {
          const cf = msg.countryFilter || 'ALL';
          const lf = msg.langFilter || 'ALL';
          matchQueue.set(freshUser.id, {
            countryFilter: cf,
            langFilter: lf,
            joinedAt: Date.now(),
          });
          pushLiveCandidatesToUser(freshUser, cf, lf);
          // Notify other queued users that a new real peer joined the queue!
          for (const [queuedUid, qCriteria] of matchQueue.entries()) {
            if (queuedUid !== freshUser.id) {
              const qUser = serverDB.users.get(queuedUid);
              if (qUser) {
                pushLiveCandidatesToUser(qUser, qCriteria.countryFilter, qCriteria.langFilter);
              }
            }
          }
        } else if (msg.type === 'match:leave_queue') {
          matchQueue.delete(freshUser.id);
        }
      } catch {
        // Ignore malformed WS frames
      }
    });

    ws.on('close', () => {
      const set = activeSockets.get(user.id);
      if (set) {
        set.delete(ws);
        if (set.size === 0) {
          activeSockets.delete(user.id);
          matchQueue.delete(user.id);
        }
      }
      const existing = serverDB.users.get(user.id);
      if (existing) {
        existing.last_seen_at = Date.now();
        serverDB.scheduleSave();
      }
      broadcastOnlinePresence();
    });
  });

  // ============================================================================
  // REST API ROUTES
  // ============================================================================

  // Health & Server Info (for Android connection check)
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      ok: true,
      package: 'com.fadfadahnative',
      version: '3.8.2',
      onlineUsers: activeSockets.size,
      totalRegisteredUsers: serverDB.users.size,
    });
  });

  // 1. Register new real device account
  app.post('/api/auth/register', (req: Request, res: Response) => {
    const { nickname, avatar_url, country, languages, interests } = (req.body || {}) as {
      nickname?: string;
      avatar_url?: string;
      country?: string;
      languages?: string[];
      interests?: string[];
    };
    const { user, link, rawToken } = serverDB.registerNewUser({
      nickname,
      avatar_url,
      country,
      languages,
      interests,
    });

    const { auth_token_hash: _hidden, ...safeSelf } = user;
    res.json({
      authToken: rawToken,
      selfUser: { ...safeSelf, is_self: true, is_online: true },
      personalLink: link,
    });
  });

  // 2. Full state sync on launch / reconnect
  app.get('/api/sync', (req: Request, res: Response) => {
    const user = serverDB.authenticateToken(extractBearerToken(req));
    if (!user) {
      res.status(401).json({ error: 'UNAUTHORIZED' });
      return;
    }

    const link = serverDB.getLinkForUser(user.id);
    const myRooms = Array.from(serverDB.chatRooms.values())
      .filter((r) => r.participant_a === user.id || r.participant_b === user.id)
      .map((r) => formatRoomForUser(r, user.id));

    const myRoomIds = new Set(myRooms.map((r) => r.id));
    const myMessages = Array.from(serverDB.messages.values()).filter((m) =>
      myRoomIds.has(m.room_id)
    );

    // Collect relevant peer profiles (chat peers + vent authors + online users)
    const peerIds = new Set<string>();
    for (const r of myRooms) {
      peerIds.add(r.participant_a === user.id ? r.participant_b : r.participant_a);
    }
    for (const v of serverDB.publicVents.values()) {
      peerIds.add(v.author_id);
    }
    for (const onlineUid of activeSockets.keys()) {
      peerIds.add(onlineUid);
    }
    for (const u of serverDB.users.values()) {
      peerIds.add(u.id);
    }
    peerIds.delete(user.id);

    const peerProfiles = Array.from(peerIds)
      .map((pid) => serverDB.users.get(pid))
      .filter((p): p is ServerUserRecord => Boolean(p))
      .map((p) => serverDB.toPublicUser(p, isUserOnline(p.id)));

    const vents = Array.from(serverDB.publicVents.values())
      .sort((a, b) => b.created_at - a.created_at)
      .slice(0, 100)
      .map((v) => ({
        id: v.id,
        author_id: v.author_id,
        topic: v.topic,
        content: v.content,
        likes_count: v.liked_user_ids.length,
        liked_by_me: v.liked_user_ids.includes(user.id),
        ai_flag_score: v.ai_flag_score,
        created_at: v.created_at,
      }));

    const { auth_token_hash: _hidden, ...safeSelf } = user;
    res.json({
      selfUser: { ...safeSelf, is_self: true, is_online: true },
      personalLink: link,
      rooms: myRooms,
      messages: myMessages,
      peers: peerProfiles,
      vents,
    });
  });

  // 3. Update Profile & Custom Personal Link Slug
  app.put('/api/profile', async (req: Request, res: Response) => {
    const user = serverDB.authenticateToken(extractBearerToken(req));
    if (!user) {
      res.status(401).json({ error: 'UNAUTHORIZED' });
      return;
    }

    const { nickname, slug, country, bio, avatar_url, frame_id, interests, languages } =
      req.body as {
        nickname?: string;
        slug?: string;
        country?: string;
        bio?: string;
        avatar_url?: string;
        frame_id?: number;
        interests?: string[];
        languages?: string[];
      };

    const textToCheck = `${nickname ?? user.nickname} ${bio ?? user.bio}`;
    const isCustomImg = avatar_url?.startsWith('data:image/');
    const mod = await moderateServerContent(
      textToCheck,
      isCustomImg ? avatar_url : undefined,
      isCustomImg ? avatar_url?.slice(5, avatar_url.indexOf(';')) : undefined
    );
    if (mod.isFrozen) {
      res.status(400).json({ error: mod.reasonAr || 'بيانات الملف الشخصي مخالفة لإرشادات الأمان.' });
      return;
    }

    if (nickname?.trim()) user.nickname = nickname.trim().slice(0, 24);
    if (country) user.country = country.slice(0, 32);
    if (typeof bio === 'string') user.bio = bio.trim().slice(0, 120);
    if (avatar_url) user.avatar_url = avatar_url;
    if (typeof frame_id === 'number' && (user.is_premium || user.unlocked_frames.includes(frame_id))) {
      user.frame_id = frame_id;
    }
    if (Array.isArray(interests) && interests.length > 0) {
      user.interests = interests.slice(0, 12);
    }
    if (Array.isArray(languages) && languages.length > 0) {
      user.languages = languages.slice(0, 5);
    }
    user.embedding_vector = computeServerEmbedding(user.interests, user.languages);

    const link = serverDB.getLinkForUser(user.id);
    if (link && slug?.trim()) {
      const oldSlug = link.slug.toLowerCase();
      const uniqueSlug = serverDB.reserveUniqueSlug(slug, user.id);
      serverDB.slugIndex.delete(oldSlug);
      link.slug = uniqueSlug;
      serverDB.slugIndex.set(uniqueSlug, link.id);
    }

    serverDB.scheduleSave();
    broadcastAll({
      type: 'peer:updated',
      peer: serverDB.toPublicUser(user, isUserOnline(user.id)),
    });

    const { auth_token_hash: _hidden, ...safeSelf } = user;
    res.json({
      selfUser: { ...safeSelf, is_self: true, is_online: true },
      personalLink: link,
    });
  });

  // 4. Lookup Public Personal Link (/api/links/:slug)
  app.get('/api/links/:slug', (req: Request, res: Response) => {
    const link = serverDB.getLinkBySlug(req.params.slug || '');
    if (!link || !link.is_active) {
      res.status(404).json({ error: 'LINK_NOT_FOUND' });
      return;
    }
    const targetUser = serverDB.users.get(link.user_id);
    if (!targetUser) {
      res.status(404).json({ error: 'USER_NOT_FOUND' });
      return;
    }

    link.visits_count += 1;
    serverDB.scheduleSave();

    // Notify link owner live if connected
    sendToUser(targetUser.id, {
      type: 'link:updated',
      personalLink: link,
    });

    res.json({
      slug: link.slug,
      visits_count: link.visits_count,
      targetUser: serverDB.toPublicUser(targetUser, isUserOnline(targetUser.id)),
    });
  });

  // 5. Send Real Anonymous Message via Personal Link -> Creates Real Two-Way Chat Thread!
  app.post('/api/links/:slug/send', async (req: Request, res: Response) => {
    const link = serverDB.getLinkBySlug(req.params.slug || '');
    if (!link || !link.is_active) {
      res.status(404).json({ error: 'الرابط الشخصي غير موجود أو غير مفعل.' });
      return;
    }
    const recipient = serverDB.users.get(link.user_id);
    if (!recipient) {
      res.status(404).json({ error: 'صاحب الرابط غير موجود.' });
      return;
    }

    const { content, senderAlias, senderAvatar } = (req.body || {}) as {
      content?: string;
      senderAlias?: string;
      senderAvatar?: string;
    };
    const cleanText = (content || '').trim().slice(0, 1500);
    if (!cleanText) {
      res.status(400).json({ error: 'نص الرسالة مطلوب.' });
      return;
    }

    const mod = await moderateServerContent(cleanText);
    if (mod.isFrozen) {
      res.status(400).json({ error: mod.reasonAr, reasonEn: mod.reasonEn, isFrozen: true });
      return;
    }

    // Check if sender already has an authenticated account, or register a real visitor account for 2-way chat!
    let sender = serverDB.authenticateToken(extractBearerToken(req));
    let issuedToken: string | undefined;
    let issuedLink = sender ? serverDB.getLinkForUser(sender.id) : undefined;

    if (!sender || sender.id === recipient.id) {
      const reg = serverDB.registerNewUser({
        nickname: senderAlias?.trim() || `زائر_${Math.floor(100 + Math.random() * 899)}`,
        avatar_url: senderAvatar || 'moon',
      });
      sender = reg.user;
      issuedToken = reg.rawToken;
      issuedLink = reg.link;
    } else if (senderAlias?.trim()) {
      sender.nickname = senderAlias.trim().slice(0, 24);
      if (senderAvatar) sender.avatar_url = senderAvatar;
    }

    if (recipient.blocked_user_ids.includes(sender.id)) {
      res.status(403).json({ error: 'لا يمكن إرسال رسالة لهذا المستخدم.' });
      return;
    }

    const now = Date.now();
    const roomId = `room-link-${crypto.randomUUID().slice(0, 8)}`;
    const room: ServerChatRoom = {
      id: roomId,
      type: 'LINK_BASED',
      participant_a: recipient.id,
      participant_b: sender.id,
      status: 'ACCEPTED',
      unread_a: 1,
      unread_b: 0,
      last_message_preview: cleanText,
      last_message_at: now,
      created_at: now,
    };

    const msgId = `msg-${crypto.randomUUID().slice(0, 8)}`;
    const message = {
      id: msgId,
      room_id: roomId,
      sender_id: sender.id,
      content: cleanText,
      media_url: '',
      media_type: 'text' as MediaType,
      ai_flag_score: mod.flagScore,
      ai_flag_reason: '',
      is_frozen: false,
      status: 'SENT' as const,
      created_at: now,
    };

    serverDB.chatRooms.set(room.id, room);
    serverDB.messages.set(message.id, message);
    serverDB.scheduleSave();

    // Push real-time event to recipient's Android device!
    sendToUser(recipient.id, {
      type: 'room:upsert',
      room: formatRoomForUser(room, recipient.id),
      peer: serverDB.toPublicUser(sender, isUserOnline(sender.id)),
      message,
    });

    // Also push to sender if they have active sockets
    sendToUser(sender.id, {
      type: 'room:upsert',
      room: formatRoomForUser(room, sender.id),
      peer: serverDB.toPublicUser(recipient, isUserOnline(recipient.id)),
      message,
    });

    const { auth_token_hash: _hidden, ...safeSender } = sender;
    res.json({
      room: formatRoomForUser(room, sender.id),
      message,
      recipientPeer: serverDB.toPublicUser(recipient, isUserOnline(recipient.id)),
      issuedAuthToken: issuedToken,
      issuedSelfUser: issuedToken ? { ...safeSender, is_self: true, is_online: true } : undefined,
      issuedPersonalLink: issuedLink,
    });
  });

  // 6. Initiate Real Random Match / Chat Request
  app.post('/api/match/request', (req: Request, res: Response) => {
    const user = serverDB.authenticateToken(extractBearerToken(req));
    if (!user) {
      res.status(401).json({ error: 'UNAUTHORIZED' });
      return;
    }

    const { targetPeerId, introText } = (req.body || {}) as {
      targetPeerId?: string;
      introText?: string;
    };
    const peer = targetPeerId ? serverDB.users.get(targetPeerId) : undefined;
    if (!peer || peer.id === user.id) {
      res.status(404).json({ error: 'المستخدم غير متاح حالياً.' });
      return;
    }
    if (user.blocked_user_ids.includes(peer.id) || peer.blocked_user_ids.includes(user.id)) {
      res.status(403).json({ error: 'لا يمكن بدء محادثة مع هذا المستخدم.' });
      return;
    }

    // Check if a room already exists between these two real users
    const existingRoom = Array.from(serverDB.chatRooms.values()).find(
      (r) =>
        r.status !== 'BLOCKED' &&
        ((r.participant_a === user.id && r.participant_b === peer.id) ||
          (r.participant_b === user.id && r.participant_a === peer.id))
    );

    if (existingRoom) {
      if (existingRoom.status === 'PENDING' && existingRoom.participant_b === user.id) {
        existingRoom.status = 'ACCEPTED';
        serverDB.scheduleSave();
        sendToUser(peer.id, {
          type: 'room:upsert',
          room: formatRoomForUser(existingRoom, peer.id),
          peer: serverDB.toPublicUser(user, isUserOnline(user.id)),
        });
      }
      res.json({
        room: formatRoomForUser(existingRoom, user.id),
        peer: serverDB.toPublicUser(peer, isUserOnline(peer.id)),
      });
      return;
    }

    // Enforce Free Tier Daily Quota (5/day) unless Premium
    const todayStr = new Date().toISOString().slice(0, 10);
    const usedToday = user.last_random_date === todayStr ? user.daily_random_count : 0;
    if (!user.is_premium && usedToday >= 5) {
      res.status(429).json({ error: 'DAILY_QUOTA_REACHED' });
      return;
    }

    user.daily_random_count = usedToday + 1;
    user.last_random_date = todayStr;

    // If BOTH users are actively searching in the live Matchmaking Queue right now, pair as ACCEPTED immediately!
    // Otherwise create a real PENDING chat request ("طلبات المحادثة الواردة" - Report Section 2.2)
    const bothInLiveQueue = matchQueue.has(user.id) && matchQueue.has(peer.id);
    const initialStatus: ChatRoomStatus = bothInLiveQueue ? 'ACCEPTED' : 'PENDING';
    if (bothInLiveQueue) {
      matchQueue.delete(user.id);
      matchQueue.delete(peer.id);
    }

    const now = Date.now();
    const roomId = `room-rand-${crypto.randomUUID().slice(0, 8)}`;
    const cleanIntro =
      (introText || '').trim().slice(0, 500) ||
      `طلب محادثة عشوائية من ${user.nickname}`;

    const room: ServerChatRoom = {
      id: roomId,
      type: 'RANDOM',
      participant_a: user.id,
      participant_b: peer.id,
      status: initialStatus,
      unread_a: 0,
      unread_b: 1,
      last_message_preview: cleanIntro,
      last_message_at: now,
      created_at: now,
    };

    const msg = {
      id: `msg-${crypto.randomUUID().slice(0, 8)}`,
      room_id: roomId,
      sender_id: user.id,
      content: cleanIntro,
      media_url: '',
      media_type: 'text' as MediaType,
      ai_flag_score: 0.0,
      ai_flag_reason: '',
      is_frozen: false,
      status: 'SENT' as const,
      created_at: now,
    };

    serverDB.chatRooms.set(room.id, room);
    serverDB.messages.set(msg.id, msg);
    serverDB.scheduleSave();

    sendToUser(peer.id, {
      type: 'room:upsert',
      room: formatRoomForUser(room, peer.id),
      peer: serverDB.toPublicUser(user, isUserOnline(user.id)),
      message: msg,
    });

    const { auth_token_hash: _hidden, ...safeSelf } = user;
    res.json({
      room: formatRoomForUser(room, user.id),
      message: msg,
      peer: serverDB.toPublicUser(peer, isUserOnline(peer.id)),
      selfUser: { ...safeSelf, is_self: true, is_online: true },
    });
  });

  // 7. Accept or Reject Incoming Chat Request
  app.post('/api/rooms/:roomId/respond', (req: Request, res: Response) => {
    const user = serverDB.authenticateToken(extractBearerToken(req));
    if (!user) {
      res.status(401).json({ error: 'UNAUTHORIZED' });
      return;
    }

    const room = serverDB.chatRooms.get(req.params.roomId || '');
    if (!room || (room.participant_a !== user.id && room.participant_b !== user.id)) {
      res.status(404).json({ error: 'ROOM_NOT_FOUND' });
      return;
    }

    const { action } = (req.body || {}) as { action?: 'ACCEPT' | 'REJECT' };
    const peerId = room.participant_a === user.id ? room.participant_b : room.participant_a;

    if (action === 'REJECT') {
      serverDB.chatRooms.delete(room.id);
      for (const [mId, m] of serverDB.messages.entries()) {
        if (m.room_id === room.id) serverDB.messages.delete(mId);
      }
      serverDB.scheduleSave();
      sendToUser(peerId, { type: 'room:deleted', roomId: room.id });
      res.json({ deleted: true, roomId: room.id });
      return;
    }

    room.status = 'ACCEPTED';
    if (room.participant_a === user.id) room.unread_a = 0;
    else room.unread_b = 0;
    serverDB.scheduleSave();

    const peer = serverDB.users.get(peerId);
    sendToUser(peerId, {
      type: 'room:upsert',
      room: formatRoomForUser(room, peerId),
      peer: serverDB.toPublicUser(user, isUserOnline(user.id)),
    });

    res.json({
      room: formatRoomForUser(room, user.id),
      peer: peer ? serverDB.toPublicUser(peer, isUserOnline(peer.id)) : undefined,
    });
  });

  // 8. Send Real Message in Room (Text, Sticker, or Image)
  app.post('/api/rooms/:roomId/messages', async (req: Request, res: Response) => {
    const user = serverDB.authenticateToken(extractBearerToken(req));
    if (!user) {
      res.status(401).json({ error: 'UNAUTHORIZED' });
      return;
    }

    const room = serverDB.chatRooms.get(req.params.roomId || '');
    if (!room || room.status === 'BLOCKED') {
      res.status(404).json({ error: 'المحادثة غير متاحة.' });
      return;
    }
    if (room.participant_a !== user.id && room.participant_b !== user.id) {
      res.status(403).json({ error: 'FORBIDDEN' });
      return;
    }

    const { id: clientMsgId, content, media_url, media_type } = (req.body || {}) as {
      id?: string;
      content?: string;
      media_url?: string;
      media_type?: MediaType;
    };

    // Idempotency guard against duplicate retries
    if (clientMsgId && serverDB.messages.has(clientMsgId)) {
      res.json({ message: serverDB.messages.get(clientMsgId), room: formatRoomForUser(room, user.id) });
      return;
    }

    const cleanContent = (content || '').trim().slice(0, 2000);
    const mType: MediaType = media_type || 'text';
    if (!cleanContent && !media_url) {
      res.status(400).json({ error: 'EMPTY_MESSAGE' });
      return;
    }

    const isImg = mType === 'image' && media_url?.startsWith('data:image/');
    const mod =
      mType === 'sticker'
        ? { flagScore: 0, isFrozen: false, reasonAr: '', reasonEn: '' }
        : await moderateServerContent(
            cleanContent,
            isImg ? media_url : undefined,
            isImg ? media_url?.slice(5, media_url.indexOf(';')) : undefined
          );

    const now = Date.now();
    const message = {
      id: clientMsgId && /^[a-zA-Z0-9_-]{4,64}$/.test(clientMsgId)
        ? clientMsgId
        : `msg-${crypto.randomUUID().slice(0, 8)}`,
      room_id: room.id,
      sender_id: user.id,
      content: cleanContent || 'صورة مرفقة',
      media_url: mod.isFrozen ? '' : media_url || '',
      media_type: mType,
      ai_flag_score: mod.flagScore,
      ai_flag_reason: mod.reasonAr,
      is_frozen: mod.isFrozen,
      status: 'SENT' as const,
      created_at: now,
    };

    serverDB.messages.set(message.id, message);

    const peerId = room.participant_a === user.id ? room.participant_b : room.participant_a;
    if (!mod.isFrozen) {
      room.last_message_preview = message.content;
      room.last_message_at = now;
      if (room.participant_a === peerId) room.unread_a += 1;
      else room.unread_b += 1;
    }

    serverDB.scheduleSave();

    // Only deliver non-frozen messages to the other user!
    if (!mod.isFrozen) {
      sendToUser(peerId, {
        type: 'message:created',
        message,
        room: formatRoomForUser(room, peerId),
        senderPeer: serverDB.toPublicUser(user, true),
      });
    }

    sendToUser(user.id, {
      type: 'message:created',
      message,
      room: formatRoomForUser(room, user.id),
    });

    res.json({
      message,
      room: formatRoomForUser(room, user.id),
    });
  });

  // 9. Mark Room Messages as READ (✓✓)
  app.post('/api/rooms/:roomId/read', (req: Request, res: Response) => {
    const user = serverDB.authenticateToken(extractBearerToken(req));
    if (!user) {
      res.status(401).json({ error: 'UNAUTHORIZED' });
      return;
    }
    const room = serverDB.chatRooms.get(req.params.roomId || '');
    if (!room || (room.participant_a !== user.id && room.participant_b !== user.id)) {
      res.status(404).json({ error: 'NOT_FOUND' });
      return;
    }

    if (room.participant_a === user.id) room.unread_a = 0;
    else room.unread_b = 0;

    const updatedIds: string[] = [];
    for (const m of serverDB.messages.values()) {
      if (m.room_id === room.id && m.sender_id !== user.id && m.status !== 'READ') {
        m.status = 'READ';
        updatedIds.push(m.id);
      }
    }
    serverDB.scheduleSave();

    const peerId = room.participant_a === user.id ? room.participant_b : room.participant_a;
    if (updatedIds.length > 0) {
      sendToUser(peerId, {
        type: 'messages:read',
        roomId: room.id,
        messageIds: updatedIds,
      });
    }

    res.json({ ok: true, room: formatRoomForUser(room, user.id) });
  });

  // 10. Block User Permanently
  app.post('/api/rooms/:roomId/block', (req: Request, res: Response) => {
    const user = serverDB.authenticateToken(extractBearerToken(req));
    if (!user) {
      res.status(401).json({ error: 'UNAUTHORIZED' });
      return;
    }
    const room = serverDB.chatRooms.get(req.params.roomId || '');
    if (!room || (room.participant_a !== user.id && room.participant_b !== user.id)) {
      res.status(404).json({ error: 'NOT_FOUND' });
      return;
    }

    const peerId = room.participant_a === user.id ? room.participant_b : room.participant_a;
    room.status = 'BLOCKED';
    if (!user.blocked_user_ids.includes(peerId)) {
      user.blocked_user_ids.push(peerId);
    }
    serverDB.scheduleSave();

    sendToUser(peerId, { type: 'room:deleted', roomId: room.id });
    res.json({ ok: true, blockedPeerId: peerId });
  });

  // 11. Submit Moderation Report
  app.post('/api/reports', async (req: Request, res: Response) => {
    const user = serverDB.authenticateToken(extractBearerToken(req));
    if (!user) {
      res.status(401).json({ error: 'UNAUTHORIZED' });
      return;
    }

    const { roomId, reportedUserId, reason } = (req.body || {}) as {
      roomId?: string;
      reportedUserId?: string;
      reason?: string;
    };
    const reported = reportedUserId ? serverDB.users.get(reportedUserId) : undefined;
    const recentMsgs = Array.from(serverDB.messages.values())
      .filter((m) => m.room_id === roomId)
      .sort((a, b) => a.created_at - b.created_at)
      .slice(-10)
      .map((m) => ({
        sender: m.sender_id === user.id ? user.nickname : reported?.nickname || 'Peer',
        content: m.content,
      }));

    let aiSummary = `توثيق إشرافي: تم حفظ ${recentMsgs.length} رسائل حديثة لمراجعة الحساب (${
      reported?.nickname || reportedUserId
    }) بسبب: "${reason || 'مخالفة'}".`;

    const ai = getAiClient();
    if (ai) {
      try {
        const resp = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: `لخص في سطرين بالعربية بلاغ إشراف ضد "${
            reported?.nickname || 'مستخدم'
          }" للسبب "${reason}" مع السجل: ${JSON.stringify(recentMsgs)}`,
          config: { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } },
        });
        if (resp.text) aiSummary = resp.text.trim();
      } catch {
        // Keep standalone summary
      }
    }

    const rep = {
      id: `rep-${crypto.randomUUID().slice(0, 8)}`,
      reporter_id: user.id,
      reported_user_id: reportedUserId || '',
      room_id: roomId || '',
      reason: reason || 'مخالفة',
      recent_messages_log: JSON.stringify(recentMsgs),
      ai_summary: aiSummary,
      created_at: Date.now(),
    };
    serverDB.reports.set(rep.id, rep);
    serverDB.scheduleSave();

    res.json({ report: rep });
  });

  // 12. Public Venting Wall: Publish, Like, and Private Reply
  app.post('/api/vents', async (req: Request, res: Response) => {
    const user = serverDB.authenticateToken(extractBearerToken(req));
    if (!user) {
      res.status(401).json({ error: 'UNAUTHORIZED' });
      return;
    }

    const { topic, content } = (req.body || {}) as { topic?: string; content?: string };
    const clean = (content || '').trim().slice(0, 1200);
    if (!clean) {
      res.status(400).json({ error: 'EMPTY_CONTENT' });
      return;
    }

    const mod = await moderateServerContent(clean);
    if (mod.isFrozen) {
      res.status(400).json({ error: mod.reasonAr, isFrozen: true });
      return;
    }

    const vent = {
      id: `vent-${crypto.randomUUID().slice(0, 8)}`,
      author_id: user.id,
      topic: (topic || 'فضفضة').slice(0, 32),
      content: clean,
      liked_user_ids: [] as string[],
      ai_flag_score: mod.flagScore,
      created_at: Date.now(),
    };
    serverDB.publicVents.set(vent.id, vent);
    serverDB.scheduleSave();

    broadcastAll({
      type: 'vent:upsert',
      vent: {
        id: vent.id,
        author_id: vent.author_id,
        topic: vent.topic,
        content: vent.content,
        likes_count: 0,
        ai_flag_score: vent.ai_flag_score,
        created_at: vent.created_at,
      },
      authorPeer: serverDB.toPublicUser(user, true),
    });

    res.json({
      vent: {
        ...vent,
        likes_count: 0,
        liked_by_me: false,
      },
    });
  });

  app.post('/api/vents/:ventId/like', (req: Request, res: Response) => {
    const user = serverDB.authenticateToken(extractBearerToken(req));
    if (!user) {
      res.status(401).json({ error: 'UNAUTHORIZED' });
      return;
    }
    const vent = serverDB.publicVents.get(req.params.ventId || '');
    if (!vent) {
      res.status(404).json({ error: 'VENT_NOT_FOUND' });
      return;
    }

    const idx = vent.liked_user_ids.indexOf(user.id);
    if (idx >= 0) vent.liked_user_ids.splice(idx, 1);
    else vent.liked_user_ids.push(user.id);
    serverDB.scheduleSave();

    broadcastAll({
      type: 'vent:likes_updated',
      ventId: vent.id,
      likes_count: vent.liked_user_ids.length,
    });

    res.json({
      ventId: vent.id,
      likes_count: vent.liked_user_ids.length,
      liked_by_me: vent.liked_user_ids.includes(user.id),
    });
  });

  // 13. Subscriptions, Points, and Frame Unlocking (Ready for Google Play Billing Receipt Hook)
  app.post('/api/monetization/plan', (req: Request, res: Response) => {
    const user = serverDB.authenticateToken(extractBearerToken(req));
    if (!user) {
      res.status(401).json({ error: 'UNAUTHORIZED' });
      return;
    }
    const { plan, bonusPoints = 0 } = (req.body || {}) as {
      plan: PremiumPlan;
      bonusPoints?: number;
    };
    user.premium_plan = plan;
    user.is_premium = plan !== 'free';
    user.points += Number(bonusPoints) || 0;
    if (user.is_premium) {
      user.unlocked_frames = [0, 1, 2, 3, 4, 5];
    }
    serverDB.scheduleSave();
    broadcastOnlinePresence();

    const { auth_token_hash: _hidden, ...safeSelf } = user;
    res.json({ selfUser: { ...safeSelf, is_self: true, is_online: true } });
  });

  app.post('/api/monetization/points', (req: Request, res: Response) => {
    const user = serverDB.authenticateToken(extractBearerToken(req));
    if (!user) {
      res.status(401).json({ error: 'UNAUTHORIZED' });
      return;
    }
    const { deltaPoints = 0, unlockFrameId, unlockExtraQuota } = (req.body || {}) as {
      deltaPoints?: number;
      unlockFrameId?: number;
      unlockExtraQuota?: boolean;
    };

    if (typeof unlockFrameId === 'number') {
      const cost = Math.abs(deltaPoints);
      if (user.points < cost) {
        res.status(400).json({ error: 'INSUFFICIENT_POINTS' });
        return;
      }
      user.points -= cost;
      if (!user.unlocked_frames.includes(unlockFrameId)) {
        user.unlocked_frames.push(unlockFrameId);
      }
      user.frame_id = unlockFrameId;
    } else if (unlockExtraQuota) {
      if (user.points < 50) {
        res.status(400).json({ error: 'INSUFFICIENT_POINTS' });
        return;
      }
      user.points -= 50;
      user.daily_random_count = Math.max(0, user.daily_random_count - 3);
    } else if (deltaPoints > 0) {
      user.points += deltaPoints;
    }

    serverDB.scheduleSave();
    const { auth_token_hash: _hidden, ...safeSelf } = user;
    res.json({ selfUser: { ...safeSelf, is_self: true, is_online: true } });
  });

  // 14. Permanent Account & Data Deletion (Google Play Store UGC Policy Mandatory Endpoint)
  app.delete('/api/account', (req: Request, res: Response) => {
    const user = serverDB.authenticateToken(extractBearerToken(req));
    if (!user) {
      res.status(401).json({ error: 'UNAUTHORIZED' });
      return;
    }
    const affectedPeers = serverDB.deleteAccountCompletely(user.id);
    for (const pid of affectedPeers) {
      sendToUser(pid, { type: 'sync:needed' });
    }
    broadcastOnlinePresence();
    res.json({ deleted: true });
  });

  // Support clean /u/:slug share links redirecting smoothly into the SPA gateway (?u=slug)
  app.get('/u/:slug', (req: Request, res: Response) => {
    res.redirect(302, `/?u=${encodeURIComponent(req.params.slug || '')}`);
  });

  // Serve SPA via Vite in dev or static dist/ in production
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        watch: null,
      },
      plugins: [
        {
          name: 'fadfadah-attach-ws-server',
          config() {
            return {
              server: {
                hmr: {
                  server: httpServer,
                },
                watch: null,
              },
            };
          },
        },
      ],
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const port = Number(process.env.PORT) || 3000;
  httpServer.listen(port, '0.0.0.0', () => {
    console.log(`Fadfadah Real Server + WebSocket Hub listening on http://0.0.0.0:${port}`);
  });
}

startServer();
